/* Talks to the shop's own server. The preview build swaps this file for api-preview.js. */
window.API = (() => {
  async function req(method, url, body) {
    const opts = { method, headers: { Accept: 'application/json' }, credentials: 'same-origin' };
    if (method !== 'GET') {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body || {});
    }
    let res;
    try {
      res = await fetch(url, opts);
    } catch {
      throw new Error("We can't reach the shop right now. Check your internet connection and try again.");
    }
    let data = null;
    try { data = await res.json(); } catch { /* empty body */ }
    if (!res.ok) {
      const err = new Error((data && data.error) || `Something went wrong (error ${res.status}). Please try again.`);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  function stream(url, handlers, onState) {
    let es = null, closed = false, retry = null;
    const open = () => {
      if (closed) return;
      es = new EventSource(url, { withCredentials: true });
      es.onopen = () => onState && onState('live');
      Object.entries(handlers).forEach(([evt, fn]) => es.addEventListener(evt, (e) => {
        try { fn(JSON.parse(e.data)); } catch { /* ignore bad frame */ }
      }));
      es.onerror = () => {
        onState && onState('reconnecting');
        if (es.readyState === EventSource.CLOSED) { es.close(); retry = setTimeout(open, 4000); }
      };
    };
    open();
    return () => { closed = true; clearTimeout(retry); if (es) es.close(); };
  }

  return {
    mode: 'live',
    config: () => req('GET', '/api/config'),
    me: () => req('GET', '/api/auth/me').then((d) => d.user),
    signup: (p) => req('POST', '/api/auth/signup', p).then((d) => d.user),
    login: (p) => req('POST', '/api/auth/login', p).then((d) => d.user),
    logout: () => req('POST', '/api/auth/logout'),
    updateAccount: (p) => req('PATCH', '/api/account', p).then((d) => d.user),
    changePassword: (p) => req('POST', '/api/account/password', p),
    products: () => req('GET', '/api/products').then((d) => d.products),
    delivery: () => req('GET', '/api/delivery'),
    createOrder: (p) => req('POST', '/api/orders', p).then((d) => d.order),
    startPayment: (code) => req('POST', `/api/orders/${encodeURIComponent(code)}/pay`),
    demoPay: (code, outcome) => req('POST', `/api/orders/${encodeURIComponent(code)}/demo-pay`, { outcome }).then((d) => d.order),
    verifyPayment: (code) => req('POST', `/api/orders/${encodeURIComponent(code)}/verify`).then((d) => d.order),
    cancelOrder: (code) => req('POST', `/api/orders/${encodeURIComponent(code)}/cancel`).then((d) => d.order),
    myOrders: () => req('GET', '/api/orders').then((d) => d.orders),
    order: (code) => req('GET', `/api/orders/${encodeURIComponent(code)}`).then((d) => d.order),
    subscribeOrder: (code, onOrder, onState) => stream(`/api/orders/${encodeURIComponent(code)}/events`, { order: onOrder }, onState),

    async saveFile(filename, bytes, mime) {
      const blob = new Blob([bytes], { type: mime });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      return true;
    },
    canPrint: true,

    admin: {
      summary: () => req('GET', '/api/admin/summary'),
      orders: () => req('GET', '/api/admin/orders').then((d) => d.orders),
      updateOrder: (code, p) => req('PATCH', `/api/admin/orders/${encodeURIComponent(code)}`, p).then((d) => d.order),
      products: () => req('GET', '/api/admin/products').then((d) => d.products),
      saveProduct: (p) => (p.id
        ? req('PUT', `/api/admin/products/${encodeURIComponent(p.id)}`, p)
        : req('POST', '/api/admin/products', p)).then((d) => d.product),
      deleteProduct: (id) => req('DELETE', `/api/admin/products/${encodeURIComponent(id)}`),
      uploadImage: (dataUrl) => req('POST', '/api/admin/uploads', { dataUrl }).then((d) => d.url),
      customers: () => req('GET', '/api/admin/customers').then((d) => d.customers),
      delivery: () => req('GET', '/api/admin/delivery'),
      saveDeliverySettings: (s) => req('PUT', '/api/admin/delivery/settings', s).then((d) => d.settings),
      saveZone: (z) => (z.id
        ? req('PUT', `/api/admin/delivery/zones/${encodeURIComponent(z.id)}`, z)
        : req('POST', '/api/admin/delivery/zones', z)).then((d) => d.zone),
      deleteZone: (id) => req('DELETE', `/api/admin/delivery/zones/${encodeURIComponent(id)}`),
      resetPassword: (id) => req('POST', `/api/admin/customers/${encodeURIComponent(id)}/reset-password`).then((d) => d.tempPassword),
      subscribe: (onEvent, onState) => stream('/api/admin/events', { order: onEvent }, onState),
    },
  };
})();
