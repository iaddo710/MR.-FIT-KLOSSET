/* Builds a PDF copy of a paid order's receipt in the browser (jsPDF). */
window.ReceiptPDF = (() => {
  // PDF core fonts cover Latin-1 only, so amounts use the currency code (e.g. "NGN 12,500.00").
  function amt(minor, cfg) {
    const v = new Intl.NumberFormat(cfg.locale || 'en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(minor / 100);
    return `${cfg.currency} ${v}`;
  }
  const latin = (s) => String(s ?? '').replace(/[^\x20-\x7E\xA0-\xFF]/g, '');

  function build(order, cfg) {
    if (!window.jspdf || !window.jspdf.jsPDF) throw new Error('The PDF tool is still loading. Wait a moment and try again.');
    const doc = new window.jspdf.jsPDF({ unit: 'pt', format: 'a4' });
    const W = doc.internal.pageSize.getWidth();
    const M = 48;
    let y = 64;
    const ink = [30, 39, 42], muted = [90, 101, 103], line = [200, 206, 200];

    doc.setFont('times', 'bold'); doc.setFontSize(22); doc.setTextColor(...ink);
    doc.text(latin(cfg.shopName), M, y);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(...muted);
    const contact = [cfg.address, cfg.contactPhone, cfg.contactEmail].filter(Boolean).map(latin);
    contact.forEach((t, i) => doc.text(t, W - M, y - 14 + i * 12, { align: 'right' }));
    y += 26;
    doc.setDrawColor(...line); doc.setLineDashPattern([3, 3], 0); doc.line(M, y, W - M, y); doc.setLineDashPattern([], 0);

    y += 36;
    doc.setFont('times', 'normal'); doc.setFontSize(26); doc.setTextColor(...ink);
    doc.text('Receipt', M, y);
    doc.setDrawColor(44, 106, 69); doc.setTextColor(44, 106, 69); doc.setLineWidth(1.5);
    doc.roundedRect(W - M - 64, y - 20, 64, 26, 3, 3);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text('PAID', W - M - 32, y - 3, { align: 'center' });
    doc.setLineWidth(1);

    y += 28;
    const meta = [
      ['Receipt no.', order.receiptNo],
      ['Date paid', new Date(order.paidAt).toLocaleString(cfg.locale || 'en-US', { dateStyle: 'medium', timeStyle: 'short' })],
      ['Order', order.code],
      ['Paid with', order.paymentLabel || order.paymentProvider],
    ];
    const colW = (W - 2 * M) / 4;
    meta.forEach(([k, v], i) => {
      const x = M + i * colW;
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(...muted); doc.text(k, x, y);
      doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.setTextColor(...ink);
      doc.text(doc.splitTextToSize(latin(v), colW - 8), x, y + 14);
    });
    y += 34;
    if (order.paymentRef) {
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(...muted);
      doc.text(`Payment reference: ${latin(order.paymentRef)}`, M, y);
      y += 14;
    }

    y += 8;
    doc.setDrawColor(...line); doc.setLineDashPattern([3, 3], 0); doc.line(M, y, W - M, y); doc.setLineDashPattern([], 0);
    y += 20;
    const d = order.delivery || {};
    const billed = [order.customer?.name, order.customer?.email, order.customer?.phone].filter(Boolean).map(latin);
    const pickup = d.method === 'pickup';
    const ship = (pickup ? [cfg.shopName, cfg.address, d.name, d.phone] : [d.name, d.phone, d.address, [d.city, d.region].filter(Boolean).join(', ')]).filter(Boolean).map(latin);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(...muted);
    doc.text('Billed to', M, y); doc.text(pickup ? 'Collect from' : 'Deliver to', M + (W - 2 * M) / 2, y);
    doc.setFontSize(10); doc.setTextColor(...ink);
    const half = (W - 2 * M) / 2 - 12;
    let by = y + 14, sy = y + 14;
    billed.forEach((t) => { doc.splitTextToSize(t, half).forEach((l) => { doc.text(l, M, by); by += 13; }); });
    ship.forEach((t) => { doc.splitTextToSize(t, half).forEach((l) => { doc.text(l, M + (W - 2 * M) / 2, sy); sy += 13; }); });
    y = Math.max(by, sy) + 10;
    doc.setDrawColor(...line); doc.setLineDashPattern([3, 3], 0); doc.line(M, y, W - M, y); doc.setLineDashPattern([], 0);

    y += 24;
    const cols = [M, M + 250, M + 320, M + 360, W - M];
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.setTextColor(...muted);
    doc.text('Item', cols[0], y); doc.text('Size', cols[1], y); doc.text('Qty', cols[2], y);
    doc.text('Price', cols[3] + 70, y, { align: 'right' }); doc.text('Total', cols[4], y, { align: 'right' });
    y += 8; doc.setDrawColor(...line); doc.line(M, y, W - M, y);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.setTextColor(...ink);
    order.items.forEach((it) => {
      y += 18;
      if (y > 760) { doc.addPage(); y = 64; }
      const name = doc.splitTextToSize(latin(it.name), 240);
      doc.text(name, cols[0], y);
      doc.text(latin(it.size || '-'), cols[1], y);
      doc.text(String(it.qty), cols[2], y);
      doc.text(amt(it.price, cfg), cols[3] + 70, y, { align: 'right' });
      doc.text(amt(it.price * it.qty, cfg), cols[4], y, { align: 'right' });
      y += (name.length - 1) * 12;
    });
    y += 14; doc.line(M, y, W - M, y);

    const dlabel = pickup ? 'Pickup at shop' : latin(`Delivery to ${d.city || ''}`).slice(0, 34);
    const rows = [['Subtotal', amt(order.subtotal, cfg)], [dlabel, order.deliveryFee ? amt(order.deliveryFee, cfg) : 'Free']];
    y += 20;
    rows.forEach(([k, v]) => {
      doc.setFont('helvetica', 'normal'); doc.setTextColor(...muted); doc.text(k, W - M - 200, y);
      doc.setTextColor(...ink); doc.text(v, W - M, y, { align: 'right' }); y += 16;
    });
    doc.setDrawColor(...ink); doc.setLineWidth(1.5); doc.line(W - M - 200, y - 4, W - M, y - 4); doc.setLineWidth(1);
    y += 14;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(12);
    doc.text('Total paid', W - M - 200, y); doc.text(amt(order.total, cfg), W - M, y, { align: 'right' });

    y += 48;
    doc.setDrawColor(...line); doc.setLineDashPattern([3, 3], 0); doc.line(M, y, W - M, y); doc.setLineDashPattern([], 0);
    y += 22;
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(...muted);
    doc.splitTextToSize(latin(cfg.receiptNote || 'Thank you for shopping with us.'), W - 2 * M).forEach((l) => { doc.text(l, W / 2, y, { align: 'center' }); y += 12; });
    return doc.output('arraybuffer');
  }

  return { build };
})();
