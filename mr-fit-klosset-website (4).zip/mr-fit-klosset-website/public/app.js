/* Storefront + owner dashboard. One page, hash routes:
   #shop #bag #checkout #orders #order-CODE #pay-CODE #receipt-CODE #account
   #admin #admin-products #admin-delivery #admin-customers, and #login / #signup when signed out. */
(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const view = $('#view'), topbar = $('#topbar'), tabbar = $('#tabbar'), footer = $('#footer');

  const mem = {};
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : (k in mem ? mem[k] : d); } catch { return k in mem ? mem[k] : d; } },
    set(k, v) { mem[k] = v; try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage off */ } },
  };

  const state = { user: null, cfg: null, products: [], category: 'All', search: '', unsub: null, adminUnsub: null, afterLogin: '', lastHash: null };

  /* ---------- icons ---------- */
  const ICONS = {
    bag: '<path d="M5.5 8h13l-1 12.5h-11L5.5 8Z"/><path d="M9 10V6.5a3 3 0 0 1 6 0V10"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
    shop: '<path d="M12 7.5a2 2 0 1 1 2-2c0 1.2-2 1.6-2 3V10"/><path d="M12 10 2.5 17.5h19L12 10Z"/>',
    orders: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3Z"/><path d="M9 8h6M9 12h6"/>',
    dash: '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    check: '<path d="m5 12.5 4.5 4.5L19.5 7"/>',
    back: '<path d="M15 18l-6-6 6-6"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    truck: '<path d="M3 6h11v10H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
    alert: '<circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.5v.3"/>',
    download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
    print: '<path d="M7 9V3h10v6M7 17H4v-7h16v7h-3"/><rect x="7" y="14" width="10" height="7"/>',
    receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3Z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
    phone: '<path d="M5 3.5h3.5l2 5-2.4 1.6a11.5 11.5 0 0 0 5.8 5.8l1.6-2.4 5 2V19a2 2 0 0 1-2 2A17 17 0 0 1 3 5.5a2 2 0 0 1 2-2Z"/>',
    chat: '<path d="M4 12a8 8 0 1 1 3.4 6.5L4 20l1.3-3.7A8 8 0 0 1 4 12Z"/><path d="M9 10.5h6M9 13.5h4"/>',
  };
  const icon = (n) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;

  /* ---------- formatting ---------- */
  let nf = null;
  const money = (minor) => {
    if (!nf) nf = new Intl.NumberFormat(state.cfg.locale || 'en-US', { style: 'currency', currency: state.cfg.currency || 'USD' });
    return nf.format((minor || 0) / 100);
  };
  const when = (iso, opts) => (iso ? new Date(iso).toLocaleString(state.cfg.locale || 'en-US', opts || { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '');
  const day = (iso) => when(iso, { day: 'numeric', month: 'short', year: 'numeric' });
  const first = (name) => String(name || '').trim().split(/\s+/)[0] || 'there';
  const logo = (cls, big) => { const src = big ? state.cfg.logoLarge : state.cfg.logoSmall; return src ? `<img class="${cls}" src="${esc(src)}" alt="" width="256" height="256">` : ''; };
  // One-tap Call and WhatsApp buttons. The number stays readable on the Call button.
  function contactButtons(waText, { block = false } = {}) {
    const c = state.cfg;
    const tel = String(c.contactPhone || '').replace(/[^\d+]/g, '');
    const wa = String(c.whatsapp || '').replace(/\D/g, '');
    if (!tel && !wa) return '';
    const waHref = `https://wa.me/${wa}?text=${encodeURIComponent(waText || `Hello ${c.shopName}, `)}`;
    return `<div class="contact-btns${block ? ' contact-block' : ''}">
      ${tel ? `<a class="btn btn-call" href="tel:${esc(tel)}">${icon('phone')}<span>Call ${esc(c.contactPhone)}</span></a>` : ''}
      ${wa ? `<a class="btn btn-wa" href="${esc(waHref)}" target="_blank" rel="noopener">${icon('chat')}<span>WhatsApp us</span></a>` : ''}
    </div>`;
  }

  function productImage(p, cls = '') {
    if (p && p.image) return `<img class="pimg ${cls}" src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy">`;
    const bg = Art.safeColor(p && p.art && p.art.bg, '#E6E9E5');
    return `<div class="pimg art ${cls}" style="--art-bg:${bg}" role="img" aria-label="${esc(p ? p.name : '')}">${Art.svg(p && p.art)}</div>`;
  }

  /* ---------- order status ---------- */
  const STEPS = [
    { key: 'placed', label: 'Order placed', hint: 'We have your order.' },
    { key: 'paid', label: 'Payment confirmed', hint: 'Your receipt is ready.' },
    { key: 'processing', label: 'Being prepared', hint: 'We are checking, pressing and packing your pieces.' },
    { key: 'shipped', label: 'Shipped', hint: 'Your parcel is with the courier.' },
    { key: 'out_for_delivery', label: 'Out for delivery', hint: 'Your parcel arrives today.' },
    { key: 'delivered', label: 'Delivered', hint: 'Enjoy your new pieces.' },
  ];
  const STATUS = {
    pending_payment: { label: 'Awaiting payment', tone: 'warn', step: 0 },
    paid: { label: 'Payment confirmed', tone: 'info', step: 1 },
    processing: { label: 'Being prepared', tone: 'info', step: 2 },
    shipped: { label: 'Shipped', tone: 'info', step: 3 },
    out_for_delivery: { label: 'Out for delivery', tone: 'info', step: 4 },
    delivered: { label: 'Delivered', tone: 'good', step: 5 },
    cancelled: { label: 'Cancelled', tone: 'bad', step: -1 },
  };
  const PICKUP_STEPS = [
    STEPS[0], STEPS[1], STEPS[2],
    { key: 'shipped', label: 'Ready for pickup', hint: 'Come to the shop and quote your order number.' },
    { key: 'delivered', label: 'Collected', hint: 'Enjoy your new pieces.' },
  ];
  const PICKUP_LABEL = { shipped: 'Ready for pickup', out_for_delivery: 'Ready for pickup', delivered: 'Collected' };
  const ORDERED = ['pending_payment', 'paid', 'processing', 'shipped', 'out_for_delivery', 'delivered'];
  const STEP_RANK = { placed: 0, paid: 1, processing: 2, shipped: 3, out_for_delivery: 4, delivered: 5 };
  const isPickup = (o) => !!(o && o.delivery && o.delivery.method === 'pickup');
  const stepsFor = (o) => (isPickup(o) ? PICKUP_STEPS : STEPS);
  const statusLabel = (status, o) => (isPickup(o) && PICKUP_LABEL[status]) || (STATUS[status] ? STATUS[status].label : status);
  const pill = (status, o) => { const t = STATUS[status] ? STATUS[status].tone : 'info'; return `<span class="pill pill-${t}">${esc(statusLabel(status, o))}</span>`; };
  const isPaid = (o) => !!o.paidAt;
  function reachedRank(o) {
    if (o.status !== 'cancelled') return Math.max(0, ORDERED.indexOf(o.status));
    let max = 0;
    (o.events || []).forEach((e) => { const r = ORDERED.indexOf(e.status); if (r > max) max = r; });
    return max;
  }
  const stepIndex = (st, rank) => st.reduce((idx, s, i) => (STEP_RANK[s.key] <= rank ? i : idx), 0);
  function reachedStep(o) { return stepIndex(stepsFor(o), reachedRank(o)); }
  function nextStatus(status, o) {
    const i = ORDERED.indexOf(status);
    if (i < 0 || i >= ORDERED.length - 1) return null;
    const n = ORDERED[i + 1];
    return isPickup(o) && n === 'out_for_delivery' ? 'delivered' : n;
  }
  const placeLine = (d) => (d.method === 'pickup' ? 'Pick up at our shop' : [d.city, d.region].filter(Boolean).join(', '));

  /* ---------- delivery locations ---------- */
  async function loadDelivery(force) { if (!state.delivery || force) state.delivery = await API.delivery(); return state.delivery; }
  const zoneById = (id) => (state.delivery ? state.delivery.zones.find((z) => z.id === id) : null) || null;
  const kmText = (km) => `${Math.round(km)} km`;
  function zoneOptions(selected, q) {
    const { zones, settings } = state.delivery;
    const ql = String(q || '').trim().toLowerCase();
    const match = (z) => !ql || z.name.toLowerCase().includes(ql) || z.region.toLowerCase().includes(ql);
    const opt = (z) => `<option value="${esc(z.id)}" ${z.id === selected ? 'selected' : ''}>${esc(z.name)}, ${money(Delivery.zoneFee(z, settings))}</option>`;
    const near = zones.filter((z) => z.km <= 25 && match(z)).sort((a, b) => a.km - b.km);
    const regions = Array.from(new Set([...Delivery.REGIONS, ...zones.map((z) => z.region)]));
    let count = near.length;
    let html = near.length ? `<optgroup label="Near our shop">${near.map(opt).join('')}</optgroup>` : '';
    regions.forEach((r) => {
      const list = zones.filter((z) => z.region === r && z.km > 25 && match(z)).sort((a, b) => a.name.localeCompare(b.name));
      count += list.length;
      if (list.length) html += `<optgroup label="${esc(r)} Region">${list.map(opt).join('')}</optgroup>`;
    });
    const first = ql ? (count ? `Choose from ${count} match${count === 1 ? '' : 'es'}` : 'No town matches that name') : 'Choose your town or area';
    return { html: `<option value="">${first}</option>${html}`, count };
  }
  function zonePicker(prefix, selected) {
    return `<div class="zone-pick">
      <label class="field"><span>Find your town or area</span><input id="${prefix}-q" type="search" placeholder="Type a name, e.g. Nsawam, Kasoa, Kumasi" autocomplete="off"></label>
      <label class="field"><span>Delivery location</span><select id="${prefix}-zone" name="zoneId">${zoneOptions(selected, '').html}</select></label>
    </div>`;
  }
  function bindZonePicker(root, prefix, onChange) {
    const q = $(`#${prefix}-q`, root), sel = $(`#${prefix}-zone`, root);
    q.addEventListener('input', () => {
      const keep = sel.value;
      const r = zoneOptions(keep, q.value);
      sel.innerHTML = r.html;
      const opts = $$('option[value]:not([value=""])', sel);
      if (opts.some((o) => o.value === keep)) sel.value = keep;
      else if (opts.length === 1) sel.value = opts[0].value;
      else sel.value = '';
      onChange(sel.value);
    });
    sel.addEventListener('change', () => onChange(sel.value));
  }

  /* ---------- toasts + modals ---------- */
  function toast(msg, opts = {}) {
    const el = document.createElement('div');
    el.className = 'toast' + (opts.tone === 'bad' ? ' toast-bad' : '');
    el.innerHTML = `<span>${esc(msg)}</span>${opts.action ? `<button type="button">${esc(opts.action.label)}</button>` : ''}`;
    if (opts.action) el.querySelector('button').addEventListener('click', () => { el.remove(); opts.action.run(); });
    const box = $('#toasts');
    box.appendChild(el);
    while (box.children.length > 2) box.firstElementChild.remove();
    setTimeout(() => el.remove(), opts.ms || 4500);
  }

  let lastFocus = null;
  function openModal(html, { wide = false, onMount } = {}) {
    lastFocus = document.activeElement;
    const root = $('#modal-root');
    root.innerHTML = `<div class="scrim" data-close></div><div class="modal ${wide ? 'modal-wide' : ''}" role="dialog" aria-modal="true"><button type="button" class="modal-x" data-close aria-label="Close">${icon('close')}</button>${html}</div>`;
    root.hidden = false;
    document.body.classList.add('no-scroll');
    $$('[data-close]', root).forEach((b) => b.addEventListener('click', closeModal));
    const m = $('.modal', root);
    if (onMount) onMount(m);
    const f = $('h2', m);
    if (f) { f.tabIndex = -1; f.focus(); }
    return m;
  }
  function closeModal() {
    const root = $('#modal-root');
    if (root.hidden) return;
    root.hidden = true; root.innerHTML = '';
    document.body.classList.remove('no-scroll');
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  function confirmBox({ title, body, yes, danger }) {
    return new Promise((resolve) => {
      let done = false;
      const m = openModal(`<h2>${esc(title)}</h2><p class="muted" style="margin:10px 0 22px">${esc(body)}</p>
        <div class="row" style="justify-content:flex-end"><button class="btn" type="button" id="cf-no">Keep it</button><button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" type="button" id="cf-yes">${esc(yes)}</button></div>`);
      const finish = (v) => { if (done) return; done = true; closeModal(); resolve(v); };
      $('#cf-yes', m).addEventListener('click', () => finish(true));
      $('#cf-no', m).addEventListener('click', () => finish(false));
      $$('[data-close]', $('#modal-root')).forEach((b) => b.addEventListener('click', () => finish(false)));
    });
  }

  function busy(btn, on, label) {
    if (!btn) return;
    if (on) { btn.dataset.label = btn.innerHTML; btn.setAttribute('aria-busy', 'true'); btn.disabled = true; btn.innerHTML = `<span class="spinner" aria-hidden="true" style="width:16px;height:16px;border-width:2px"></span>${esc(label || 'Working…')}`; }
    else { btn.removeAttribute('aria-busy'); btn.disabled = false; if (btn.dataset.label) btn.innerHTML = btn.dataset.label; }
  }
  const loading = (msg = 'Loading…') => `<div class="boot"><span class="spinner" aria-hidden="true"></span><span>${esc(msg)}</span></div>`;
  function failView(err, retry) {
    view.innerHTML = `<div class="wrap empty"><h2>That didn't load</h2><p class="muted">${esc(err.message)}</p><button class="btn btn-primary" id="retry">Try again</button></div>`;
    $('#retry').addEventListener('click', retry);
  }

  /* ---------- bag ---------- */
  const bagKey = () => `bag:${state.user ? state.user.id : 'anon'}`;
  const getBag = () => store.get(bagKey(), []);
  const setBag = (b) => { store.set(bagKey(), b); paintCounts(); };
  const bagCount = () => getBag().reduce((n, i) => n + i.qty, 0);
  function bagLines() {
    return getBag().map((i) => ({ ...i, product: state.products.find((p) => p.id === i.productId) })).filter((l) => l.product && l.product.active !== false);
  }
  function addToBag(productId, size, qty) {
    const b = getBag();
    const hit = b.find((i) => i.productId === productId && i.size === size);
    if (hit) hit.qty = Math.min(20, hit.qty + qty); else b.push({ productId, size, qty });
    setBag(b);
  }
  function paintCounts() {
    const n = bagCount();
    $$('[data-bag-count]').forEach((el) => { el.textContent = n; el.hidden = el.classList.contains('dot') && n === 0; });
  }

  /* ---------- chrome ---------- */
  function chrome(active) {
    const u = state.user, owner = u.role === 'admin';
    topbar.hidden = false; footer.hidden = false; tabbar.hidden = false;
    topbar.innerHTML = `<div class="wrap topbar-in">
      <a class="brand" href="#shop" aria-label="${esc(state.cfg.shopName)} home">${logo('brand-logo')}<span>${esc(state.cfg.shopName)}</span></a>
      <nav class="mainnav" aria-label="Main">
        <a href="#shop" class="${active === 'shop' ? 'on' : ''}">Shop</a>
        <a href="#orders" class="${active === 'orders' ? 'on' : ''}">My orders</a>
        ${owner ? `<a href="#admin" class="${active === 'admin' ? 'on' : ''}">Owner dashboard</a>` : ''}
      </nav>
      <div class="topbar-actions">
        <a class="iconbtn" href="#account" aria-label="Your account">${icon('user')}<span class="hide-sm">${esc(first(u.name))}</span></a>
        <a class="bagbtn" href="#bag" aria-label="Your bag">${icon('bag')}<span class="hide-sm">Bag</span><span class="count" data-bag-count>0</span></a>
      </div></div>`;
    const tabs = [['shop', 'Shop', 'shop'], ['bag', 'Bag', 'bag'], ['orders', 'Orders', 'orders']];
    if (owner) tabs.push(['admin', 'Dashboard', 'dash']);
    tabs.push(['account', 'Account', 'user']);
    tabbar.style.setProperty('--tabs', tabs.length);
    tabbar.innerHTML = tabs.map(([h, l, i]) => `<a href="#${h}" class="${active === h ? 'on' : ''}">${icon(i)}${l}${h === 'bag' ? '<span class="dot" data-bag-count hidden>0</span>' : ''}</a>`).join('');
    const c = state.cfg;
    footer.innerHTML = `<div class="wrap footer-in">
      <div class="footer-brand">${logo('footer-logo', true)}<div><strong>${esc(c.shopName)}</strong><br>${esc(c.address || '')}</div></div>
      <div class="stack" style="gap:10px"><span>Questions about an order? Call or WhatsApp us.${c.contactEmail ? `<br>${esc(c.contactEmail)}` : ''}</span>${contactButtons()}</div>
    </div>`;
    paintCounts();
  }
  function hideChrome() { topbar.hidden = true; tabbar.hidden = true; footer.hidden = true; }

  function previewBar() {
    const bar = $('#preview-bar');
    if (API.mode !== 'preview') { bar.hidden = true; return; }
    bar.hidden = false;
    const owner = state.user && state.user.role === 'admin';
    bar.innerHTML = `<span>Preview with sample data. Payments are simulated.</span>
      ${state.user ? `<button type="button" id="pv-switch">${owner ? 'Switch to customer view' : 'Switch to owner view'}</button>` : ''}
      <button type="button" id="pv-reset">Reset preview</button>`;
    const sw = $('#pv-switch');
    if (sw) sw.addEventListener('click', async () => {
      const u = await API.preview.switchTo(owner ? 'customer' : 'owner');
      state.user = u;
      previewBar();
      if (!u) { location.hash = 'signup'; route(); return; }
      location.hash = u.role === 'admin' ? 'admin' : 'shop';
      route();
    });
    $('#pv-reset').addEventListener('click', async () => {
      if (!(await confirmBox({ title: 'Reset the preview?', body: 'This clears the sample accounts, orders and products you changed in this browser and starts fresh.', yes: 'Reset preview', danger: true }))) return;
      API.preview.reset(); location.hash = ''; location.reload();
    });
  }

  /* ---------- auth wall ---------- */
  function viewAuth(mode) {
    hideChrome(); stopLive();
    const c = state.cfg, signup = mode === 'signup';
    view.innerHTML = `<div class="auth">
      <aside class="auth-brand pinstripe">
        <div class="auth-tape" aria-hidden="true"></div>
        <div class="auth-brand-in">
          ${logo('auth-logo', true)}
          <div class="wordmark">${esc(c.shopName)}</div>
          <p>${esc(c.tagline || '')}</p>
          <ul class="auth-points">
            <li>Shop the full collection in your size</li>
            <li>Pay securely online and get an instant receipt</li>
            <li>Follow your order live, from our rail to your door</li>
          </ul>
        </div>
      </aside>
      <section class="auth-main">
        <div class="auth-card">
          <div class="seg" role="tablist" aria-label="Account">
            <button type="button" role="tab" aria-selected="${signup}" data-mode="signup">Create account</button>
            <button type="button" role="tab" aria-selected="${!signup}" data-mode="login">Sign in</button>
          </div>
          <div class="stack" style="gap:6px">
            <h1>${signup ? 'Create your account' : 'Welcome back'}</h1>
            <p class="muted">${signup ? 'You need an account to shop, pay and track your orders. It takes under a minute.' : 'Sign in to shop and see your orders.'}</p>
          </div>
          <form id="auth-form" novalidate>
            ${signup ? `<label class="field"><span>Full name</span><input id="f-name" name="name" autocomplete="name" required></label>` : ''}
            <label class="field"><span>Email</span><input id="f-email" name="email" type="email" autocomplete="email" inputmode="email" required></label>
            ${signup ? `<label class="field"><span>Phone number</span><input id="f-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required><small>For delivery updates from the courier.</small></label>` : ''}
            <label class="field"><span>Password</span><span class="pw-wrap"><input id="f-pass" name="password" type="password" autocomplete="${signup ? 'new-password' : 'current-password'}" minlength="8" required><button type="button" class="pw-toggle" id="pw-toggle" aria-controls="f-pass">Show</button></span>${signup ? '<small>At least 8 characters.</small>' : ''}</label>
            <p class="form-error" id="auth-err" role="alert" hidden></p>
            <button class="btn btn-primary btn-block" type="submit" id="auth-go">${signup ? 'Create account' : 'Sign in'}</button>
          </form>
          ${signup ? '' : `<div class="stack" style="gap:10px"><p class="small muted">Forgot your password? Call or WhatsApp us and we'll reset it for you.</p>${contactButtons(`Hello ${c.shopName}, I forgot my password. My email is `)}</div>`}
          ${API.mode === 'preview' ? `<div class="preview-note"><span><strong>Preview:</strong> sign up as a customer with any details, or open the owner dashboard to see orders, products and customers.</span><button class="btn btn-sm" type="button" id="pv-owner">Open the owner dashboard</button></div>` : ''}
        </div>
      </section>
    </div>`;
    $$('.seg button').forEach((b) => b.addEventListener('click', () => { location.hash = b.dataset.mode; }));
    $('#pw-toggle').addEventListener('click', (e) => {
      const i = $('#f-pass'); const show = i.type === 'password';
      i.type = show ? 'text' : 'password'; e.currentTarget.textContent = show ? 'Hide' : 'Show';
    });
    const pv = $('#pv-owner');
    if (pv) pv.addEventListener('click', async () => { state.user = await API.preview.switchTo('owner'); location.hash = 'admin'; afterAuth(); });
    $('#auth-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const err = $('#auth-err'); err.hidden = true;
      $$('input', e.target).forEach((i) => i.removeAttribute('aria-invalid'));
      const v = Object.fromEntries(new FormData(e.target).entries());
      const bad = (id, msg) => { const el = $(id); el.setAttribute('aria-invalid', 'true'); el.focus(); err.textContent = msg; err.hidden = false; };
      if (signup && (v.name || '').trim().length < 2) return bad('#f-name', 'Enter your full name.');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test((v.email || '').trim())) return bad('#f-email', 'Enter a valid email address, like name@example.com.');
      if (signup && (v.phone || '').replace(/\D/g, '').length < 7) return bad('#f-phone', 'Enter a phone number we can reach you on.');
      if ((v.password || '').length < 8) return bad('#f-pass', 'Your password needs at least 8 characters.');
      const btn = $('#auth-go');
      busy(btn, true, signup ? 'Creating account…' : 'Signing in…');
      try {
        state.user = signup ? await API.signup(v) : await API.login(v);
        store.set('hasAccount', true);
        toast(signup ? `Welcome, ${first(state.user.name)}. Your account is ready.` : `Welcome back, ${first(state.user.name)}.`);
        afterAuth();
      } catch (ex) {
        busy(btn, false); err.textContent = ex.message; err.hidden = false;
      }
    });
    const f = $(signup ? '#f-name' : '#f-email'); if (f) f.focus();
  }
  function afterAuth() {
    const target = state.afterLogin && !['login', 'signup'].includes(state.afterLogin) ? state.afterLogin : (state.user.role === 'admin' ? 'admin' : 'shop');
    state.afterLogin = '';
    if (location.hash.slice(1) === target) route(); else location.hash = target;
    previewBar();
  }

  /* ---------- shop ---------- */
  async function viewShop() {
    chrome('shop');
    const c = state.cfg;
    const dset = state.delivery ? state.delivery.settings : null;
    const deliveryLine = `We deliver to your town, priced by distance from our shop${dset && dset.pickup ? ', or you can pick up for free' : ''}. `;
    view.innerHTML = `<section class="wrap shop-intro">
        <h1 class="display">Shop the collection</h1>
        <p class="lede">${esc(deliveryLine)}Pay securely online, get your receipt straight away and follow your parcel live.</p>
      </section>
      <section class="wrap shop-tools" aria-label="Find products">
        <label class="search">${icon('search')}<span class="sr-only">Search products</span><input id="q" type="search" placeholder="Search polos, shirts, sets, hoodies…" value="${esc(state.search)}" autocomplete="off"></label>
        <div class="chips" id="chips"></div>
      </section>
      <section class="wrap" aria-label="Products"><div id="grid">${loading('Loading the collection…')}</div></section>`;
    $('#q').addEventListener('input', (e) => { state.search = e.target.value; paintGrid(); });
    try { [state.products] = await Promise.all([API.products(), loadDelivery().catch(() => null)]); } catch (err) { return failView(err, viewShop); }
    const lede = $('.shop-intro .lede');
    if (lede && state.delivery) lede.textContent = `We deliver to your town, priced by distance from our shop${state.delivery.settings.pickup ? ', or you can pick up for free' : ''}. Pay securely online, get your receipt straight away and follow your order live.`;
    paintCounts(); paintChips(); paintGrid();
  }
  function paintChips() {
    const cats = ['All', ...state.cfg.categories.filter((cat) => state.products.some((p) => p.category === cat))];
    state.products.forEach((p) => { if (!cats.includes(p.category)) cats.push(p.category); });
    if (!cats.includes(state.category)) state.category = 'All';
    $('#chips').innerHTML = cats.map((cat) => {
      const n = cat === 'All' ? state.products.length : state.products.filter((p) => p.category === cat).length;
      return `<button type="button" class="chip" aria-pressed="${state.category === cat}" data-cat="${esc(cat)}">${esc(cat)}<span class="n">${n}</span></button>`;
    }).join('');
    $$('#chips .chip').forEach((b) => b.addEventListener('click', () => { state.category = b.dataset.cat; paintChips(); paintGrid(); }));
  }
  function paintGrid() {
    const q = state.search.trim().toLowerCase();
    const list = state.products.filter((p) => (state.category === 'All' || p.category === state.category)
      && (!q || [p.name, p.category, p.description, (p.sizes || []).join(' ')].join(' ').toLowerCase().includes(q)));
    const grid = $('#grid');
    if (!list.length) {
      grid.innerHTML = `<div class="empty"><h2>Nothing matches “${esc(state.search)}”</h2><p class="muted">Try another word, or browse everything.</p><button class="btn" id="clear-q">Show all products</button></div>`;
      $('#clear-q').addEventListener('click', () => { state.search = ''; state.category = 'All'; $('#q').value = ''; paintChips(); paintGrid(); });
      return;
    }
    grid.innerHTML = `<div class="grid">${list.map((p) => {
      const sold = p.stock === 0;
      const sizes = p.sizes && p.sizes.length ? (p.sizes.length > 1 ? `Sizes ${p.sizes[0]} to ${p.sizes[p.sizes.length - 1]}` : `Size ${p.sizes[0]}`) : 'One size';
      return `<article class="card">
        <button type="button" class="card-media" data-product="${esc(p.id)}" aria-label="View ${esc(p.name)}" style="--art-bg:${Art.safeColor(p.art && p.art.bg, '#E6E9E5')}">
          ${productImage(p)}
          <span class="tag">${money(p.price)}</span>
          ${sold ? '<span class="sold">Sold out</span>' : ''}
        </button>
        <div class="card-text">
          <h3><button type="button" class="linklike" data-product="${esc(p.id)}">${esc(p.name)}</button></h3>
          <p class="small muted">${esc(sizes)}</p>
        </div>
      </article>`;
    }).join('')}</div>`;
    $$('[data-product]', grid).forEach((b) => b.addEventListener('click', () => openProduct(b.dataset.product)));
  }

  function openProduct(id) {
    const p = state.products.find((x) => x.id === id);
    if (!p) return;
    const sold = p.stock === 0;
    let size = p.sizes && p.sizes.length === 1 ? p.sizes[0] : null, qty = 1;
    const maxQty = p.stock == null ? 20 : Math.max(1, Math.min(20, p.stock));
    const m = openModal(`<div class="pd">
      <div class="pd-media">${productImage(p)}</div>
      <div class="pd-info">
        <p class="small muted">${esc(p.category)}</p>
        <h2>${esc(p.name)}</h2>
        <p class="pd-price">${money(p.price)}</p>
        <p>${esc(p.description || '')}</p>
        ${p.sizes && p.sizes.length ? `<fieldset class="sizes"><legend>Choose your size</legend><div class="size-row">${p.sizes.map((s) => `<button type="button" class="size" data-size="${esc(s)}" aria-pressed="${size === s}">${esc(s)}</button>`).join('')}</div></fieldset>` : ''}
        <div class="row"><span style="font-weight:600;font-size:.92rem">Quantity</span>
          <div class="stepper"><button type="button" id="q-minus" aria-label="One less">${icon('minus')}</button><output id="q-val" aria-live="polite">1</output><button type="button" id="q-plus" aria-label="One more">${icon('plus')}</button></div></div>
        ${p.stock != null && p.stock > 0 && p.stock <= 5 ? `<p class="low">Only ${p.stock} left</p>` : ''}
        <p class="form-error" id="pd-err" role="alert" hidden></p>
        <button class="btn btn-primary btn-block" type="button" id="pd-add" ${sold ? 'disabled' : ''}>${sold ? 'Sold out' : `${icon('bag')} Add to bag`}</button>
      </div></div>`, { wide: true });
    const paintQty = () => { $('#q-val', m).textContent = qty; $('#q-minus', m).disabled = qty <= 1; $('#q-plus', m).disabled = qty >= maxQty; };
    paintQty();
    $('#q-minus', m).addEventListener('click', () => { qty = Math.max(1, qty - 1); paintQty(); });
    $('#q-plus', m).addEventListener('click', () => { qty = Math.min(maxQty, qty + 1); paintQty(); });
    $$('.size', m).forEach((b) => b.addEventListener('click', () => {
      size = b.dataset.size; $$('.size', m).forEach((x) => x.setAttribute('aria-pressed', String(x === b))); $('#pd-err', m).hidden = true;
    }));
    $('#pd-add', m).addEventListener('click', () => {
      if (p.sizes && p.sizes.length && !size) { const e = $('#pd-err', m); e.textContent = 'Choose a size first.'; e.hidden = false; return; }
      addToBag(p.id, size || '', qty);
      closeModal();
      toast(`Added to your bag: ${p.name}${size ? `, size ${size}` : ''}`, { action: { label: 'View bag', run: () => { location.hash = 'bag'; } } });
    });
  }

  /* ---------- bag + checkout ---------- */
  async function ensureProducts() { if (!state.products.length) state.products = await API.products(); }

  async function viewBag() {
    chrome('bag');
    view.innerHTML = loading();
    try { await Promise.all([ensureProducts(), loadDelivery()]); } catch (err) { return failView(err, viewBag); }
    const lines = bagLines();
    if (!lines.length) {
      view.innerHTML = `<div class="wrap empty"><h2>Your bag is empty</h2><p class="muted">Add a few pieces and they'll wait here for you.</p><a class="btn btn-primary" href="#shop">Browse the shop</a></div>`;
      return;
    }
    const sub = lines.reduce((s, l) => s + l.product.price * l.qty, 0);
    const ds = state.delivery.settings, saved = state.user.zoneId;
    const savedZone = saved === 'pickup' ? 'pickup' : zoneById(saved);
    const fee = savedZone ? Delivery.feeFor(savedZone, ds, sub) : null;
    const feeLabel = savedZone === 'pickup' ? 'Pickup' : savedZone ? `Delivery to ${savedZone.name}` : 'Delivery';
    const toFree = ds.freeOver && savedZone !== 'pickup' ? ds.freeOver - sub : 0;
    view.innerHTML = `<section class="wrap page-head">${steps(0)}<h1 style="margin-top:14px">Your bag</h1></section>
      <section class="wrap split">
        <div class="panel"><ul class="lines">${lines.map((l, i) => `<li class="line">
          ${productImage(l.product)}
          <div class="line-info"><strong>${esc(l.product.name)}</strong>
            <span class="small muted">${l.size ? `Size ${esc(l.size)}` : 'One size'}, ${money(l.product.price)} each</span>
            <div class="line-actions">
              <div class="stepper"><button type="button" data-dec="${i}" aria-label="One less" ${l.qty <= 1 ? 'disabled' : ''}>${icon('minus')}</button><output>${l.qty}</output><button type="button" data-inc="${i}" aria-label="One more">${icon('plus')}</button></div>
              <button type="button" class="btn btn-quiet btn-sm" data-rm="${i}">Remove</button>
            </div></div>
          <div class="line-total">${money(l.product.price * l.qty)}</div></li>`).join('')}</ul></div>
        <aside class="panel summary">
          <h2>Summary</h2>
          <dl class="sum-rows"><div><dt>Subtotal</dt><dd>${money(sub)}</dd></div><div><dt>${esc(feeLabel)}</dt><dd>${fee == null ? 'At checkout' : fee ? money(fee) : 'Free'}</dd></div><div class="total"><dt>${fee == null ? 'Total before delivery' : 'Total'}</dt><dd>${money(sub + (fee || 0))}</dd></div></dl>
          ${fee == null ? '<p class="small muted">Delivery is priced by distance from our shop. You choose your town at checkout.</p>' : ''}
          ${toFree > 0 ? `<p class="small muted">Add ${money(toFree)} more for free delivery.</p>` : (ds.freeOver && fee === 0 && savedZone !== 'pickup' ? '<p class="free-note">Your delivery is free.</p>' : '')}
          <a class="btn btn-primary btn-block" href="#checkout">Go to checkout</a>
          <a class="btn btn-quiet btn-block" href="#shop">Keep shopping</a>
        </aside></section>`;
    const change = (i, fn) => { const b = getBag().filter((x) => state.products.some((p) => p.id === x.productId)); fn(b, i); setBag(b.filter((x) => x.qty > 0)); viewBag(); };
    $$('[data-inc]').forEach((b) => b.addEventListener('click', () => change(+b.dataset.inc, (bag, i) => { bag[i].qty = Math.min(20, bag[i].qty + 1); })));
    $$('[data-dec]').forEach((b) => b.addEventListener('click', () => change(+b.dataset.dec, (bag, i) => { bag[i].qty -= 1; })));
    $$('[data-rm]').forEach((b) => b.addEventListener('click', () => change(+b.dataset.rm, (bag, i) => { bag[i].qty = 0; })));
  }

  function steps(current) {
    const names = ['Bag', 'Delivery', 'Payment', 'Receipt'];
    return `<ol class="steps" aria-label="Checkout progress">${names.map((n, i) => `<li class="${i < current ? 'done' : i === current ? 'now' : ''}" ${i === current ? 'aria-current="step"' : ''}><span class="steps-n">${i < current ? icon('check') : i + 1}</span>${n}</li>`).join('')}</ol>`;
  }

  async function viewCheckout() {
    chrome('bag');
    view.innerHTML = loading();
    try { await Promise.all([ensureProducts(), loadDelivery(true)]); } catch (err) { return failView(err, viewCheckout); }
    const lines = bagLines();
    if (!lines.length) { location.hash = 'bag'; return; }
    const u = state.user, c = state.cfg, ds = state.delivery.settings;
    const sub = lines.reduce((s, l) => s + l.product.price * l.qty, 0);
    let method = u.zoneId === 'pickup' && ds.pickup ? 'pickup' : 'delivery';
    let zoneId = zoneById(u.zoneId) ? u.zoneId : '';
    const providerName = c.paymentName || 'our payment partner';
    view.innerHTML = `<section class="wrap page-head"><a class="back" href="#bag">${icon('back')}Back to bag</a>${steps(1)}<h1 style="margin-top:14px">Delivery details</h1></section>
      <section class="wrap split">
        <form class="panel stack" id="co-form" novalidate>
          ${ds.pickup ? `<fieldset class="choices"><legend>How would you like to get your order?</legend>
            <label class="choice"><input type="radio" name="method" value="delivery" ${method === 'delivery' ? 'checked' : ''}><span><strong>Deliver to me</strong><small>Priced by distance from our shop</small></span></label>
            <label class="choice"><input type="radio" name="method" value="pickup" ${method === 'pickup' ? 'checked' : ''}><span><strong>Pick up at our shop</strong><small>Free</small></span></label>
          </fieldset>` : ''}
          <div class="form-grid">
            <label class="field"><span>Full name</span><input id="d-name" name="name" autocomplete="name" value="${esc(u.name)}" required></label>
            <label class="field"><span>Phone number</span><input id="d-phone" name="phone" type="tel" autocomplete="tel" value="${esc(u.phone)}" required></label>
          </div>
          <div class="stack" id="deliver-fields">
            ${zonePicker('d', zoneId)}
            <p class="zone-note" id="z-note" aria-live="polite"></p>
            <label class="field"><span>House address or landmark</span><input id="d-address" name="address" autocomplete="street-address" value="${esc(u.address)}" placeholder="House number, street, or a landmark near you"></label>
          </div>
          <div class="banner banner-info" id="pickup-info" hidden>${icon('shop')}<div><strong>Collect from our shop</strong><p>${esc(c.address || '')}. We'll call you when your order is ready.</p></div></div>
          <label class="field"><span>Notes for us (optional)</span><textarea id="d-notes" name="notes" placeholder="Best time to deliver, directions, alterations you discussed with us…"></textarea></label>
          <label class="check"><input type="checkbox" id="d-save" name="save" ${u.zoneId ? '' : 'checked'}> Remember these details for next time</label>
          <p class="form-error" id="co-err" role="alert" hidden></p>
        </form>
        <aside class="panel summary">
          <h2>Your order</h2>
          <ul class="mini-lines">${lines.map((l) => `<li>${productImage(l.product)}<span class="grow">${esc(l.product.name)}<br><span class="muted small">${l.size ? `Size ${esc(l.size)}, ` : ''}qty ${l.qty}</span></span><span class="num">${money(l.product.price * l.qty)}</span></li>`).join('')}</ul>
          <dl class="sum-rows"><div><dt>Subtotal</dt><dd>${money(sub)}</dd></div><div><dt id="sum-dl">Delivery</dt><dd id="sum-dv">Choose your town</dd></div><div class="total"><dt>Total</dt><dd id="sum-total">${money(sub)}</dd></div></dl>
          <button class="btn btn-primary btn-block" type="submit" form="co-form" id="co-pay">${icon('lock')} Pay ${money(sub)}</button>
          <p class="secure">${icon('lock')}<span>${c.paymentProvider === 'demo' ? `Test mode: no real money moves.${c.paymentMethods ? ` In the live shop, customers pay with ${esc(c.paymentMethods)} on a secure payment page.` : ''}` : `You'll pay with ${esc(c.paymentMethods || 'card')} on ${esc(providerName)}'s secure page. We never see your card details${/mobile money/i.test(c.paymentMethods || '') ? ' or Mobile Money PIN' : ''}.`}</span></p>
        </aside></section>`;
    const paint = () => {
      const pickup = method === 'pickup';
      $('#deliver-fields').hidden = pickup;
      $('#pickup-info').hidden = !pickup;
      const z = zoneById(zoneId);
      const fee = pickup ? 0 : (z ? Delivery.feeFor(z, ds, sub) : null);
      $('#sum-dl').textContent = pickup ? 'Pickup at our shop' : z ? `Delivery to ${z.name}` : 'Delivery';
      $('#sum-dv').textContent = fee == null ? 'Choose your town' : fee ? money(fee) : 'Free';
      $('#sum-total').textContent = money(sub + (fee || 0));
      if (!$('#co-pay').disabled) $('#co-pay').innerHTML = fee == null ? `${icon('lock')} Continue to payment` : `${icon('lock')} Pay ${money(sub + fee)}`;
      $('#z-note').innerHTML = z
        ? `<strong>${esc(z.name)}</strong>${z.region ? `, ${esc(z.region)} Region` : ''}, is about ${kmText(z.km)} from our shop. Delivery costs <strong>${fee ? money(fee) : 'nothing'}</strong>${fee === 0 && ds.freeOver ? ' because your order qualifies for free delivery' : ''}.`
        : "Can't find your area? Choose the nearest town and add directions below.";
    };
    $$('input[name="method"]').forEach((r) => r.addEventListener('change', () => { method = r.value; $('#co-err').hidden = true; paint(); }));
    bindZonePicker(view, 'd', (id) => {
      zoneId = id;
      if (id) { $('#co-err').hidden = true; $('#d-zone').removeAttribute('aria-invalid'); }
      paint();
    });
    paint();
    $('#co-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const err = $('#co-err'); err.hidden = true;
      $$('input', e.target).forEach((i) => i.removeAttribute('aria-invalid'));
      const v = Object.fromEntries(new FormData(e.target).entries());
      const bad = (id, msg) => { const el = $(id); el.setAttribute('aria-invalid', 'true'); el.focus(); err.textContent = msg; err.hidden = false; };
      if ((v.name || '').trim().length < 2) return bad('#d-name', 'Enter the name of the person receiving the parcel.');
      if ((v.phone || '').replace(/\D/g, '').length < 7) return bad('#d-phone', 'Enter a phone number the courier can call.');
      if (method === 'delivery' && !zoneId) return bad('#d-zone', 'Choose your delivery location. Type your town in the search box to find it quickly.');
      if (method === 'delivery' && (v.address || '').trim().length < 4) return bad('#d-address', 'Enter your house address or a landmark near you, so the rider can find you.');
      const btn = $('#co-pay');
      busy(btn, true, 'Placing your order…');
      try {
        const choice = method === 'pickup' ? 'pickup' : zoneId;
        if ($('#d-save').checked) state.user = await API.updateAccount({ phone: v.phone, address: method === 'pickup' ? state.user.address : v.address, zoneId: choice });
        const order = await API.createOrder({
          items: bagLines().map((l) => ({ productId: l.productId, size: l.size, qty: l.qty })),
          delivery: { zoneId: choice, name: v.name, phone: v.phone, address: method === 'pickup' ? '' : v.address, notes: v.notes },
        });
        setBag([]);
        busy(btn, true, 'Opening secure payment…');
        const pay = await API.startPayment(order.code);
        if (pay && pay.redirectUrl) { location.href = pay.redirectUrl; return; }
        location.hash = `pay-${order.code}`;
      } catch (ex) {
        busy(btn, false); err.textContent = ex.message; err.hidden = false;
        state.products = await API.products().catch(() => state.products);
      }
    });
  }

  /* ---------- payment ---------- */
  async function viewPay(code) {
    chrome('orders');
    view.innerHTML = loading('Loading your order…');
    let o;
    try { o = await API.order(code); } catch (err) { return failView(err, () => viewPay(code)); }
    if (isPaid(o)) { location.hash = `receipt-${o.code}`; return; }
    if (o.status === 'cancelled') { location.hash = `order-${o.code}`; return; }
    const c = state.cfg, failed = state.flash === 'failed' || o.paymentError;
    state.flash = null;
    const test = c.paymentProvider === 'demo';
    view.innerHTML = `<section class="wrap narrow page-head">${steps(2)}<h1 style="margin-top:14px">${test ? 'Test payment' : 'Finish your payment'}</h1>
      <p class="muted">Order ${esc(o.code)}, ${o.items.reduce((n, i) => n + i.qty, 0)} item${o.items.reduce((n, i) => n + i.qty, 0) === 1 ? '' : 's'}</p></section>
      <section class="wrap narrow stack">
        ${failed ? `<div class="banner banner-bad">${icon('alert')}<div><strong>Your payment didn't go through</strong><p>${esc(o.paymentError || 'No money was taken.')} Try again, or use a different card.</p></div></div>` : ''}
        <div class="panel stack">
          <dl class="sum-rows"><div><dt>Subtotal</dt><dd>${money(o.subtotal)}</dd></div><div><dt>${esc(isPickup(o) ? 'Pickup at our shop' : `Delivery to ${o.delivery.city || ''}`)}</dt><dd>${o.deliveryFee ? money(o.deliveryFee) : 'Free'}</dd></div><div class="total"><dt>Amount to pay</dt><dd>${money(o.total)}</dd></div></dl>
          ${test ? `<div class="demo-tools"><strong>This shop is in test mode</strong><span>No card details are needed and no money moves. Choose what the payment should do.</span>
              <div class="row"><button class="btn btn-primary" id="t-ok">${icon('lock')} Complete test payment</button><button class="btn" id="t-fail">Simulate a declined card</button></div></div>`
            : `<button class="btn btn-primary btn-block" id="go-pay">${icon('lock')} Pay ${money(o.total)} with ${esc(c.paymentName)}</button>
              ${c.paymentMethods ? `<p class="small muted" style="text-align:center">On the next page, choose ${esc(c.paymentMethods)}.</p>` : ''}
              <button class="btn btn-quiet btn-block" id="check-pay">I've already paid, check again</button>`}
          <p class="secure">${icon('lock')}<span>Your order is saved. If you leave now, you can finish paying from My orders.</span></p>
          <div class="stack" style="gap:8px"><span class="small muted">Trouble paying? Call or WhatsApp us.</span>${contactButtons(`Hello ${c.shopName}, I need help paying for order ${o.code}.`, { block: true })}</div>
        </div>
        <a class="back" href="#order-${esc(o.code)}">${icon('back')}See order details</a>
      </section>`;
    if (test) {
      $('#t-ok').addEventListener('click', async (e) => {
        busy(e.currentTarget, true, 'Confirming payment…');
        try { await API.demoPay(o.code, 'success'); state.flash = 'paid'; location.hash = `receipt-${o.code}`; } catch (ex) { busy(e.currentTarget, false); toast(ex.message, { tone: 'bad' }); }
      });
      $('#t-fail').addEventListener('click', async (e) => {
        busy(e.currentTarget, true, 'Trying card…');
        try { await API.demoPay(o.code, 'fail'); state.flash = 'failed'; viewPay(o.code); } catch (ex) { busy(e.currentTarget, false); toast(ex.message, { tone: 'bad' }); }
      });
    } else {
      $('#go-pay').addEventListener('click', async (e) => {
        busy(e.currentTarget, true, 'Opening secure payment…');
        try { const r = await API.startPayment(o.code); if (r.redirectUrl) location.href = r.redirectUrl; } catch (ex) { busy(e.currentTarget, false); toast(ex.message, { tone: 'bad' }); }
      });
      $('#check-pay').addEventListener('click', async (e) => {
        busy(e.currentTarget, true, 'Checking with the bank…');
        try {
          const fresh = await API.verifyPayment(o.code);
          if (isPaid(fresh)) { state.flash = 'paid'; location.hash = `receipt-${o.code}`; } else { busy(e.currentTarget, false); toast("We haven't received this payment yet. If money left your account, it usually confirms within a few minutes."); }
        } catch (ex) { busy(e.currentTarget, false); toast(ex.message, { tone: 'bad' }); }
      });
    }
  }

  /* ---------- receipt ---------- */
  async function viewReceipt(code) {
    chrome('orders');
    view.innerHTML = loading('Loading your receipt…');
    let o;
    try { o = await API.order(code); } catch (err) { return failView(err, () => viewReceipt(code)); }
    if (!isPaid(o)) { location.hash = o.status === 'cancelled' ? `order-${o.code}` : `pay-${o.code}`; return; }
    const c = state.cfg, just = state.flash === 'paid';
    state.flash = null;
    const d = o.delivery || {}, cu = o.customer || {};
    view.innerHTML = `<section class="wrap narrow receipt-page">
      ${just ? `${steps(4)}<div class="banner banner-good">${icon('check')}<div><strong>Payment received. Thank you!</strong><p>Here is your receipt. We've started on your order and you can follow it live.</p></div></div>` : `<a class="back" href="#order-${esc(o.code)}">${icon('back')}Back to order</a>`}
      <article class="receipt" id="receipt" aria-label="Receipt">
        <header class="rc-head"><div class="rc-brand">${logo('rc-logo')}<span>${esc(c.shopName)}</span></div><div class="small">${[c.address, c.contactPhone, c.contactEmail].filter(Boolean).map(esc).join('<br>')}</div></header>
        <div class="rc-title"><h1>Receipt</h1><span class="rc-paid">PAID</span></div>
        <dl class="rc-meta">
          <div><dt>Receipt no.</dt><dd>${esc(o.receiptNo)}</dd></div>
          <div><dt>Date paid</dt><dd>${esc(when(o.paidAt, { dateStyle: 'medium', timeStyle: 'short' }))}</dd></div>
          <div><dt>Order</dt><dd>${esc(o.code)}</dd></div>
          <div><dt>Paid with</dt><dd>${esc(o.paymentLabel || o.paymentProvider)}</dd></div>
          ${o.paymentRef ? `<div><dt>Payment reference</dt><dd>${esc(o.paymentRef)}</dd></div>` : ''}
        </dl>
        <div class="rc-cols">
          <div><h3>Billed to</h3>${[cu.name, cu.email, cu.phone].filter(Boolean).map(esc).join('<br>')}</div>
          <div>${isPickup(o) ? `<h3>Collect from</h3>${[c.shopName, c.address, d.name, d.phone].filter(Boolean).map(esc).join('<br>')}` : `<h3>Deliver to</h3>${[d.name, d.phone, d.address, placeLine(d)].filter(Boolean).map(esc).join('<br>')}`}</div>
        </div>
        <div class="rc-table-wrap"><table class="rc-items"><thead><tr><th>Item</th><th>Size</th><th class="r">Qty</th><th class="r">Price</th><th class="r">Total</th></tr></thead>
          <tbody>${o.items.map((i) => `<tr><td>${esc(i.name)}</td><td>${esc(i.size || '–')}</td><td class="r">${i.qty}</td><td class="r">${money(i.price)}</td><td class="r">${money(i.price * i.qty)}</td></tr>`).join('')}</tbody></table></div>
        <dl class="rc-totals"><div><dt>Subtotal</dt><dd>${money(o.subtotal)}</dd></div><div><dt>${esc(isPickup(o) ? 'Pickup at our shop' : `Delivery to ${o.delivery.city || ''}`)}</dt><dd>${o.deliveryFee ? money(o.deliveryFee) : 'Free'}</dd></div><div class="grand"><dt>Total paid</dt><dd>${money(o.total)}</dd></div></dl>
        <p class="rc-foot">${esc(c.receiptNote || 'Thank you for shopping with us.')}</p>
      </article>
      <div class="row no-print">
        <button class="btn btn-primary" id="rc-pdf">${icon('download')} Download PDF</button>
        ${API.canPrint ? `<button class="btn" id="rc-print">${icon('print')} Print</button>` : ''}
        <a class="btn" href="#order-${esc(o.code)}">${icon('truck')} Track this order</a>
      </div></section>`;
    $('#rc-pdf').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      busy(btn, true, 'Preparing PDF…');
      try {
        const bytes = ReceiptPDF.build(o, c);
        await API.saveFile(`receipt-${o.receiptNo}.pdf`, bytes, 'application/pdf');
      } catch (ex) {
        if (!ex || ex.code !== 'declined') toast(ex && ex.message ? ex.message : "The PDF couldn't be saved. Try again.", { tone: 'bad' });
      }
      busy(btn, false);
    });
    const pr = $('#rc-print'); if (pr) pr.addEventListener('click', () => window.print());
  }

  /* ---------- my orders + live tracking ---------- */
  async function viewOrders() {
    chrome('orders');
    view.innerHTML = `<section class="wrap page-head"><h1>My orders</h1></section><section class="wrap" id="olist">${loading()}</section>`;
    let orders;
    try { orders = await API.myOrders(); } catch (err) { return failView(err, viewOrders); }
    const box = $('#olist');
    if (!orders.length) {
      box.innerHTML = `<div class="empty"><h2>No orders yet</h2><p class="muted">When you place an order, you can follow it here, step by step.</p><a class="btn btn-primary" href="#shop">Browse the shop</a></div>`;
      return;
    }
    box.innerHTML = `<ul class="olist">${orders.map((o) => {
      const n = o.items.reduce((s, i) => s + i.qty, 0), step = reachedStep(o);
      const pct = o.status === 'cancelled' ? 0 : Math.round((step / (stepsFor(o).length - 1)) * 100);
      const href = o.status === 'pending_payment' ? `#pay-${o.code}` : `#order-${o.code}`;
      return `<li><a class="ocard" href="${href}">
        <div><h3>Order ${esc(o.code)}</h3><p class="small muted">${esc(day(o.createdAt))}, ${n} item${n === 1 ? '' : 's'}, ${money(o.total)}</p>
          <div class="thumbs">${o.items.slice(0, 5).map((i) => productImage(i)).join('')}</div></div>
        <div class="stack" style="align-items:flex-end;gap:8px">${pill(o.status, o)}<span class="small" style="color:var(--accent-text);font-weight:600">${o.status === 'pending_payment' ? 'Finish payment' : 'Track order'}</span></div>
        <div class="thread-bar" aria-hidden="true"><span style="width:${pct}%"></span></div>
      </a></li>`;
    }).join('')}</ul>`;
  }

  function trackList(o, prev) {
    const cancelled = o.status === 'cancelled';
    const st = stepsFor(o), cur = reachedStep(o);
    const times = { placed: o.createdAt };
    const notes = {};
    (o.events || []).forEach((e) => {
      const r = ORDERED.indexOf(e.status); if (r < 1) return;
      const key = st[stepIndex(st, r)].key;
      if (!times[key]) times[key] = e.at;
      if (e.note) notes[key] = e.note;
    });
    return `<ol class="track ${cancelled ? 'cancelled' : ''}">${st.map((s, i) => {
      const done = i <= cur, now = i === cur && cur < st.length - 1 && !cancelled;
      const cls = [done ? 'done' : 'todo', now ? 'now' : '', i < cur ? 'linked' : '', prev != null && i < cur && i >= prev ? 'sew' : '', prev != null && i === cur && cur > prev ? 'pop' : ''].join(' ');
      let extra = '';
      if (s.key === 'shipped' && done && isPickup(o)) extra = `<p class="small">Collect from: <strong>${esc(state.cfg.address || state.cfg.shopName)}</strong></p>`;
      else if (s.key === 'shipped' && done && (o.courier || o.trackingNo)) extra = `<p class="small">${o.courier ? `Courier: <strong>${esc(o.courier)}</strong>` : ''}${o.courier && o.trackingNo ? '<br>' : ''}${o.trackingNo ? `Tracking number: <strong>${esc(o.trackingNo)}</strong>` : ''}</p>`;
      return `<li class="tk ${cls}">
        <span class="tk-btn" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
        <div class="tk-text"><strong>${esc(s.label)}</strong>
          <span class="small muted">${done && times[s.key] ? esc(when(times[s.key])) : (now || (i === cur + 1 && !cancelled) ? (i === cur ? esc(s.hint) : 'Up next') : '')}</span>
          ${now && times[s.key] ? `<span class="small">${esc(s.hint)}</span>` : ''}
          ${extra}
          ${notes[s.key] ? `<p class="tk-note">${esc(notes[s.key])}</p>` : ''}
        </div></li>`;
    }).join('')}</ol>`;
  }

  async function viewOrder(code) {
    chrome('orders');
    view.innerHTML = loading('Loading your order…');
    let o;
    try { o = await API.order(code); } catch (err) { return failView(err, () => viewOrder(code)); }
    const c = state.cfg;
    const paint = (prev) => {
      const d = o.delivery || {}, cancelled = o.status === 'cancelled';
      const cancelNote = cancelled ? ((o.events || []).filter((e) => e.status === 'cancelled').pop() || {}).note : '';
      view.innerHTML = `<section class="wrap page-head"><a class="back" href="#orders">${icon('back')}All orders</a>
        <div class="order-top"><h1>Order ${esc(o.code)}</h1>${pill(o.status, o)}<span class="live" id="live"><span class="live-dot"></span><span id="live-t">Connecting…</span></span></div>
        <p class="muted">Placed ${esc(when(o.createdAt, { dateStyle: 'medium', timeStyle: 'short' }))}</p></section>
        <section class="wrap track-wrap">
          <div class="stack" style="gap:20px">
            ${cancelled ? `<div class="banner banner-bad">${icon('alert')}<div><strong>This order was cancelled</strong><p>${esc(cancelNote || (isPaid(o) ? 'If you paid, your refund goes back to the same card. Contact us if you have questions.' : 'No payment was taken.'))}</p></div></div>` : ''}
            ${o.status === 'pending_payment' ? `<div class="banner banner-warn">${icon('alert')}<div><strong>We're waiting for your payment</strong><p>Your order is saved but won't be prepared until it's paid.</p><div class="row" style="margin-top:10px"><a class="btn btn-primary btn-sm" href="#pay-${esc(o.code)}">Pay ${money(o.total)} now</a><button class="btn btn-sm" id="cancel-o">Cancel order</button></div></div></div>` : ''}
            <div class="panel">${trackList(o, prev)}</div>
            ${API.mode === 'preview' && !cancelled && nextStatus(o.status, o) && o.status !== 'pending_payment' ? `<div class="demo-tools"><span><strong>Preview only:</strong> in the real shop, you move orders along from the owner dashboard and customers see it here instantly.</span><button class="btn btn-sm" id="pv-next" style="width:fit-content">Move to “${esc(statusLabel(nextStatus(o.status, o), o))}”</button></div>` : ''}
          </div>
          <aside class="panel stack">
            <h2>Items</h2>
            <ul class="mini-lines">${o.items.map((i) => `<li>${productImage(i)}<span class="grow">${esc(i.name)}<br><span class="muted small">${i.size ? `Size ${esc(i.size)}, ` : ''}qty ${i.qty}</span></span><span class="num">${money(i.price * i.qty)}</span></li>`).join('')}</ul>
            <dl class="sum-rows"><div><dt>${esc(isPickup(o) ? 'Pickup at our shop' : `Delivery to ${o.delivery.city || ''}`)}</dt><dd>${o.deliveryFee ? money(o.deliveryFee) : 'Free'}</dd></div><div class="total"><dt>${isPaid(o) ? 'Total paid' : 'Total'}</dt><dd>${money(o.total)}</dd></div></dl>
            <div><h3 class="small muted" style="font-weight:600;margin-bottom:4px">${isPickup(o) ? 'Collect from our shop' : 'Delivering to'}</h3><p>${(isPickup(o) ? [c.address, d.name, d.phone] : [d.name, d.phone, d.address, placeLine(d)]).filter(Boolean).map(esc).join('<br>')}</p>${d.notes ? `<p class="small muted" style="margin-top:6px">${esc(d.notes)}</p>` : ''}</div>
            ${isPaid(o) ? `<a class="btn btn-block" href="#receipt-${esc(o.code)}">${icon('receipt')} View receipt</a>` : ''}
            <p class="small muted">Questions about this order? Call or WhatsApp us and quote order ${esc(o.code)}.</p>
            ${contactButtons(`Hello ${c.shopName}, I have a question about my order ${o.code}.`, { block: true })}
          </aside>
        </section>`;
      const cancel = $('#cancel-o');
      if (cancel) cancel.addEventListener('click', async () => {
        if (!(await confirmBox({ title: 'Cancel this order?', body: "The items go back on sale. You haven't paid, so nothing is charged.", yes: 'Cancel order', danger: true }))) return;
        try { o = await API.cancelOrder(o.code); paint(); setLive(liveState); toast('Order cancelled.'); } catch (ex) { toast(ex.message, { tone: 'bad' }); }
      });
      const pv = $('#pv-next');
      if (pv) pv.addEventListener('click', async () => {
        busy(pv, true, 'Updating…');
        try { await API.admin.updateOrder(o.code, { status: nextStatus(o.status, o), note: '' }, { asPreview: true }); } catch (ex) { busy(pv, false); toast(ex.message, { tone: 'bad' }); }
      });
    };
    let liveState = 'connecting';
    const setLive = (s) => {
      liveState = s;
      const el = $('#live'), t = $('#live-t'); if (!el) return;
      el.classList.toggle('on', s === 'live');
      t.textContent = s === 'live' ? 'Live updates on' : s === 'reconnecting' ? 'Reconnecting…' : 'Connecting…';
    };
    paint();
    stopLive();
    state.unsub = API.subscribeOrder(o.code, (next) => {
      if (!next || next.code !== o.code) return;
      const prev = reachedStep(o), changed = next.status !== o.status || next.updatedAt !== o.updatedAt;
      if (!changed) return;
      const statusChanged = next.status !== o.status;
      o = next;
      paint(statusChanged ? prev : null); setLive(liveState);
      if (statusChanged) toast(`Update on order ${o.code}: ${statusLabel(o.status, o)}`);
    }, setLive);
  }
  function stopLive() { if (state.unsub) { state.unsub(); state.unsub = null; } }

  /* ---------- account ---------- */
  function viewAccount() {
    chrome('account');
    const u = state.user;
    view.innerHTML = `<section class="wrap narrow page-head"><h1>Your account</h1><p class="muted">${esc(u.email)}</p></section>
      <section class="wrap narrow stack" style="gap:24px">
        <form class="panel stack" id="acc-form" novalidate>
          <h2>Details and delivery address</h2>
          <div class="form-grid">
            <label class="field"><span>Full name</span><input id="a-name" name="name" value="${esc(u.name)}" autocomplete="name"></label>
            <label class="field"><span>Phone number</span><input id="a-phone" name="phone" type="tel" value="${esc(u.phone)}" autocomplete="tel"></label>
          </div>
          <div id="a-zone-box">${state.delivery ? zonePicker('a', zoneById(u.zoneId) ? u.zoneId : '') : ''}</div>
          <label class="field"><span>House address or landmark</span><input id="a-address" name="address" value="${esc(u.address)}" autocomplete="street-address"></label>
          ${u.zoneId === 'pickup' ? '<p class="small muted">You usually pick up your orders at our shop.</p>' : ''}
          <p class="form-error" id="acc-err" role="alert" hidden></p>
          <button class="btn btn-primary" style="width:fit-content" type="submit" id="acc-save">Save changes</button>
        </form>
        <form class="panel stack" id="pw-form" novalidate>
          <h2>Change password</h2>
          <div class="form-grid">
            <label class="field"><span>Current password</span><input id="p-cur" name="current" type="password" autocomplete="current-password"></label>
            <label class="field"><span>New password</span><input id="p-new" name="next" type="password" autocomplete="new-password"><small>At least 8 characters.</small></label>
          </div>
          <p class="form-error" id="pw-err" role="alert" hidden></p>
          <button class="btn" style="width:fit-content" type="submit" id="pw-save">Change password</button>
        </form>
        <div class="row"><a class="btn" href="#orders">${icon('orders')} My orders</a>${u.role === 'admin' ? `<a class="btn" href="#admin">${icon('dash')} Owner dashboard</a>` : ''}<span class="spacer"></span><button class="btn btn-danger" id="logout">Sign out</button></div>
      </section>`;
    $('#acc-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const v = Object.fromEntries(new FormData(e.target).entries()), err = $('#acc-err'); err.hidden = true;
      if ((v.name || '').trim().length < 2) { err.textContent = 'Enter your full name.'; err.hidden = false; return; }
      const b = $('#acc-save'); busy(b, true, 'Saving…');
      const patch = { name: v.name, phone: v.phone, address: v.address };
      if (v.zoneId) patch.zoneId = v.zoneId;
      try { state.user = await API.updateAccount(patch); busy(b, false); toast('Changes saved.'); chrome('account'); } catch (ex) { busy(b, false); err.textContent = ex.message; err.hidden = false; }
    });
    if (state.delivery) bindZonePicker(view, 'a', () => {});
    else loadDelivery().then(() => { const box = $('#a-zone-box'); if (!box) return; box.innerHTML = zonePicker('a', zoneById(u.zoneId) ? u.zoneId : ''); bindZonePicker(view, 'a', () => {}); }).catch(() => {});
    $('#pw-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const v = Object.fromEntries(new FormData(e.target).entries()), err = $('#pw-err'); err.hidden = true;
      if ((v.next || '').length < 8) { err.textContent = 'Your new password needs at least 8 characters.'; err.hidden = false; return; }
      const b = $('#pw-save'); busy(b, true, 'Changing…');
      try { await API.changePassword(v); busy(b, false); e.target.reset(); toast('Password changed.'); } catch (ex) { busy(b, false); err.textContent = ex.message; err.hidden = false; }
    });
    $('#logout').addEventListener('click', async () => {
      try { await API.logout(); } catch { /* signed out locally anyway */ }
      state.user = null; state.products = []; store.set('hasAccount', true);
      location.hash = 'login'; previewBar(); route();
    });
  }

  /* ---------- owner dashboard ---------- */
  function adminShell(tab) {
    chrome('admin');
    view.innerHTML = `<section class="wrap page-head" style="padding-bottom:0">
        <div class="admin-head"><h1>Owner dashboard</h1><span class="live" id="a-live"><span class="live-dot"></span><span id="a-live-t">Connecting…</span></span></div>
        <nav class="tabs" aria-label="Dashboard sections">
          <a href="#admin" class="${tab === 'orders' ? 'on' : ''}">Orders</a>
          <a href="#admin-products" class="${tab === 'products' ? 'on' : ''}">Products</a>
          <a href="#admin-delivery" class="${tab === 'delivery' ? 'on' : ''}">Delivery</a>
          <a href="#admin-customers" class="${tab === 'customers' ? 'on' : ''}">Customers</a>
        </nav></section>
      <section class="wrap" id="admin-body">${loading()}</section>`;
    stopAdminLive();
    state.adminUnsub = API.admin.subscribe((evt) => {
      if (evt && evt.type === 'paid') toast(`New paid order ${evt.code} from ${evt.customer || 'a customer'}: ${money(evt.total)}`, { ms: 7000, action: { label: 'Open', run: () => openAdminOrder(evt.code) } });
      if (state.adminRefresh) state.adminRefresh();
    }, (s) => {
      const el = $('#a-live'), t = $('#a-live-t'); if (!el) return;
      el.classList.toggle('on', s === 'live'); t.textContent = s === 'live' ? 'New orders appear live' : 'Reconnecting…';
    });
  }
  function stopAdminLive() { if (state.adminUnsub) { state.adminUnsub(); state.adminUnsub = null; } state.adminRefresh = null; }

  const ADMIN_FILTERS = [
    ['todo', 'To fulfil', (o) => ['paid', 'processing', 'shipped', 'out_for_delivery'].includes(o.status)],
    ['unpaid', 'Awaiting payment', (o) => o.status === 'pending_payment'],
    ['delivered', 'Delivered', (o) => o.status === 'delivered'],
    ['cancelled', 'Cancelled', (o) => o.status === 'cancelled'],
    ['all', 'All orders', () => true],
  ];
  async function viewAdminOrders() {
    adminShell('orders');
    const body = $('#admin-body');
    state.adminFilter = state.adminFilter || 'todo';
    const load = async () => {
      let sum, orders;
      try { [sum, orders] = await Promise.all([API.admin.summary(), API.admin.orders()]); } catch (err) { body.innerHTML = `<div class="empty"><h2>That didn't load</h2><p class="muted">${esc(err.message)}</p></div>`; return; }
      if (!$('#admin-body')) return;
      const f = ADMIN_FILTERS.find((x) => x[0] === state.adminFilter) || ADMIN_FILTERS[0];
      const list = orders.filter(f[2]);
      body.innerHTML = `<div class="tiles">
          <div class="tile ${sum.toFulfil ? 'attn' : ''}"><b>${sum.toFulfil}</b><span>Orders to fulfil</span></div>
          <div class="tile"><b>${money(sum.revenueToday)}</b><span>Paid today</span></div>
          <div class="tile"><b>${money(sum.revenue30)}</b><span>Paid in the last 30 days</span></div>
          <div class="tile"><b>${sum.customers}</b><span>Customers signed up</span></div>
        </div>
        <div class="chips" style="margin-bottom:16px">${ADMIN_FILTERS.map(([k, l, fn]) => `<button type="button" class="chip" data-f="${k}" aria-pressed="${k === f[0]}">${l}<span class="n">${orders.filter(fn).length}</span></button>`).join('')}</div>
        ${list.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>Order</th><th>Customer</th><th>Placed</th><th>Items</th><th class="r">Total</th><th>Status</th><th><span class="sr-only">Action</span></th></tr></thead><tbody>
          ${list.map((o) => `<tr class="clickable" data-code="${esc(o.code)}"><td class="code">${esc(o.code)}</td><td>${esc(o.customer.name)}<br><span class="small muted">${esc(placeLine(o.delivery || {}))}</span></td><td class="small">${esc(when(o.createdAt))}</td><td>${o.items.reduce((n, i) => n + i.qty, 0)}</td><td class="r">${money(o.total)}</td><td>${pill(o.status, o)}</td><td><button class="btn btn-sm" type="button" data-code="${esc(o.code)}">${nextStatus(o.status, o) && o.status !== 'pending_payment' ? 'Update' : 'Open'}</button></td></tr>`).join('')}
        </tbody></table></div>` : `<div class="empty"><h2>Nothing here right now</h2><p class="muted">${f[0] === 'todo' ? 'Every paid order has been delivered. New paid orders show up here straight away.' : 'No orders match this filter.'}</p></div>`}`;
      $$('[data-f]', body).forEach((b) => b.addEventListener('click', () => { state.adminFilter = b.dataset.f; load(); }));
      $$('tr[data-code]', body).forEach((tr) => tr.addEventListener('click', () => openAdminOrder(tr.dataset.code)));
    };
    state.adminRefresh = load;
    load();
  }

  async function openAdminOrder(code) {
    let o;
    try { o = (await API.admin.orders()).find((x) => x.code === code); } catch (err) { toast(err.message, { tone: 'bad' }); return; }
    if (!o) { toast('That order could not be found.', { tone: 'bad' }); return; }
    const d = o.delivery || {}, cu = o.customer || {}, nxt = nextStatus(o.status, o), pick = isPickup(o);
    const m = openModal(`<div class="order-top"><h2>Order ${esc(o.code)}</h2>${pill(o.status, o)}</div>
      <p class="small muted" style="margin-top:4px">Placed ${esc(when(o.createdAt, { dateStyle: 'medium', timeStyle: 'short' }))}</p>
      <div class="am-grid">
        <div><h3>Customer</h3><p>${esc(cu.name)}<br>${esc(cu.email)}<br>${cu.phone ? `<a href="tel:${esc(cu.phone)}">${esc(cu.phone)}</a>` : ''}</p></div>
        <div><h3>${pick ? 'Pickup' : 'Deliver to'}</h3><p>${pick ? `The customer will collect from the shop.<br>${[d.name, d.phone].filter(Boolean).map(esc).join('<br>')}` : `${[d.name, d.phone, d.address, placeLine(d)].filter(Boolean).map(esc).join('<br>')}${d.km ? `<br><span class="small muted">About ${kmText(d.km)} from the shop</span>` : ''}`}</p>${d.notes ? `<p class="small muted" style="margin-top:6px">Note: ${esc(d.notes)}</p>` : ''}</div>
      </div>
      <ul class="mini-lines">${o.items.map((i) => `<li>${productImage(i)}<span class="grow">${esc(i.name)}<br><span class="muted small">${i.size ? `Size ${esc(i.size)}, ` : ''}qty ${i.qty}</span></span><span class="num">${money(i.price * i.qty)}</span></li>`).join('')}</ul>
      <dl class="kv" style="margin-top:16px"><dt>Total</dt><dd>${money(o.total)}${o.deliveryFee ? ` (includes ${money(o.deliveryFee)} delivery)` : pick ? ' (pickup, no delivery fee)' : ''}</dd>
        ${isPaid(o) ? `<dt>Paid</dt><dd>${esc(when(o.paidAt))} with ${esc(o.paymentLabel || o.paymentProvider)}</dd><dt>Receipt</dt><dd>${esc(o.receiptNo)}</dd>${o.paymentRef ? `<dt>Reference</dt><dd>${esc(o.paymentRef)}</dd>` : ''}` : '<dt>Payment</dt><dd>Not paid yet</dd>'}</dl>
      <form class="status-box" id="st-form">
        <h3 style="margin:0;color:var(--ink);font-size:1rem">Update ${pick ? 'order' : 'delivery'} status</h3>
        <p class="small muted" style="margin-top:-8px">The customer sees each update on their tracking page straight away.</p>
        ${nxt && o.status !== 'pending_payment' ? `<button type="button" class="btn btn-primary" id="st-next">${icon('check')} Mark as “${esc(statusLabel(nxt, o))}”</button>` : ''}
        <div class="form-grid">
          <label class="field full"><span>Status</span><select id="st-status">${Object.keys(STATUS).filter((k) => !(pick && k === 'out_for_delivery')).map((k) => `<option value="${k}" ${k === o.status ? 'selected' : ''}>${k === 'paid' && !isPaid(o) ? 'Payment confirmed (paid in cash or by MoMo)' : esc(statusLabel(k, o))}</option>`).join('')}</select></label>
          <label class="field" ${pick ? 'hidden' : ''}><span>Courier (optional)</span><input id="st-courier" value="${esc(o.courier)}" placeholder="e.g. our rider, or a courier company"></label>
          <label class="field" ${pick ? 'hidden' : ''}><span>Tracking number (optional)</span><input id="st-track" value="${esc(o.trackingNo)}"></label>
          <label class="field full"><span>Message to the customer (optional)</span><textarea id="st-note" placeholder="${pick ? 'e.g. Your order is ready. We are open until 7pm.' : 'e.g. Your parcel left the shop at 2pm. The rider will call before arriving.'}"></textarea></label>
        </div>
        <p class="form-error" id="st-err" role="alert" hidden></p>
        <button class="btn" type="submit" id="st-save" style="width:fit-content">Save update</button>
      </form>
      ${isPaid(o) ? `<div class="row" style="margin-top:14px"><button class="btn btn-quiet btn-sm" id="am-pdf">${icon('download')} Download receipt PDF</button></div>` : ''}`, { wide: true });
    const save = async (status, btn) => {
      const err = $('#st-err', m); err.hidden = true;
      busy(btn, true, 'Saving…');
      try {
        await API.admin.updateOrder(o.code, { status, note: $('#st-note', m).value.trim(), courier: $('#st-courier', m).value.trim(), trackingNo: $('#st-track', m).value.trim() });
        closeModal();
        toast(`Order ${o.code} is now “${statusLabel(status, o)}”. The customer can see it.`);
        if (state.adminRefresh) state.adminRefresh();
      } catch (ex) { busy(btn, false); err.textContent = ex.message; err.hidden = false; }
    };
    const nb = $('#st-next', m); if (nb) nb.addEventListener('click', () => save(nxt, nb));
    $('#st-form', m).addEventListener('submit', (e) => { e.preventDefault(); save($('#st-status', m).value, $('#st-save', m)); });
    const pdf = $('#am-pdf', m);
    if (pdf) pdf.addEventListener('click', async () => {
      try { await API.saveFile(`receipt-${o.receiptNo}.pdf`, ReceiptPDF.build(o, state.cfg), 'application/pdf'); } catch (ex) { if (!ex || ex.code !== 'declined') toast(ex.message || "The PDF couldn't be saved.", { tone: 'bad' }); }
    });
  }

  async function viewAdminProducts() {
    adminShell('products');
    const body = $('#admin-body');
    const load = async () => {
      let list;
      try { list = await API.admin.products(); } catch (err) { body.innerHTML = `<div class="empty"><h2>That didn't load</h2><p class="muted">${esc(err.message)}</p></div>`; return; }
      if (!$('#admin-body')) return;
      body.innerHTML = `<div class="row" style="margin-bottom:16px"><p class="muted">${list.length} product${list.length === 1 ? '' : 's'}. Hidden products don't show in the shop.</p><span class="spacer"></span><button class="btn btn-primary" id="p-add">${icon('plus')} Add product</button></div>
        <div class="table-wrap"><table class="table"><thead><tr><th><span class="sr-only">Photo</span></th><th>Product</th><th>Category</th><th class="r">Price</th><th class="r">In stock</th><th>Shop</th><th><span class="sr-only">Edit</span></th></tr></thead><tbody>
        ${list.map((p) => `<tr class="clickable" data-id="${esc(p.id)}"><td>${productImage(p)}</td><td><strong>${esc(p.name)}</strong><br><span class="small muted">${p.sizes && p.sizes.length ? esc(p.sizes.join(', ')) : 'One size'}</span></td><td>${esc(p.category)}</td><td class="r">${money(p.price)}</td><td class="r">${p.stock == null ? 'No limit' : p.stock === 0 ? '<span class="pill pill-bad">Sold out</span>' : p.stock}</td><td>${p.active ? '<span class="pill pill-good">Visible</span>' : '<span class="pill pill-warn">Hidden</span>'}</td><td><button class="btn btn-sm" data-id="${esc(p.id)}">Edit</button></td></tr>`).join('')}
        </tbody></table></div>`;
      $('#p-add').addEventListener('click', () => editProduct(null, load));
      $$('tr[data-id]', body).forEach((tr) => tr.addEventListener('click', () => editProduct(list.find((p) => p.id === tr.dataset.id), load)));
    };
    state.adminRefresh = null;
    load();
  }

  function resizeImage(file, max = 1000) {
    return new Promise((resolve, reject) => {
      if (!/^image\//.test(file.type)) { reject(new Error("That file isn't a photo. Choose a JPG, PNG or WebP image.")); return; }
      const url = URL.createObjectURL(file), img = new Image();
      img.onload = () => {
        const s = Math.min(1, max / Math.max(img.width, img.height));
        const cv = document.createElement('canvas'); cv.width = Math.round(img.width * s); cv.height = Math.round(img.height * s);
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        URL.revokeObjectURL(url); resolve(cv.toDataURL('image/jpeg', 0.84));
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("We couldn't read that photo. Try a JPG or PNG.")); };
      img.src = url;
    });
  }

  function editProduct(p, reload) {
    const isNew = !p;
    const draft = p ? { ...p } : { name: '', category: state.cfg.categories[0], price: 0, sizes: [], stock: null, description: '', active: true, image: null, art: { kind: 'shirt', color: '#C9CFCB', bg: '#E6E9E5' } };
    const cats = Array.from(new Set([...state.cfg.categories, draft.category]));
    const m = openModal(`<h2>${isNew ? 'Add a product' : 'Edit product'}</h2>
      <form class="stack" id="pf" novalidate style="margin-top:18px">
        <div class="photo-pick"><div id="pf-img">${productImage(draft)}</div>
          <div class="stack" style="gap:8px"><label class="btn btn-sm" style="width:fit-content;cursor:pointer">Upload photo<input type="file" id="pf-file" accept="image/*" class="sr-only"></label>
          <span class="small muted">A clear photo on a plain background works best. We resize it for you.</span>${draft.image ? '<button type="button" class="btn btn-quiet btn-sm" id="pf-noimg" style="width:fit-content">Remove photo</button>' : ''}</div></div>
        <div class="form-grid">
          <label class="field full"><span>Product name</span><input id="pf-name" value="${esc(draft.name)}" required></label>
          <label class="field"><span>Category</span><select id="pf-cat">${cats.map((c) => `<option ${c === draft.category ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select></label>
          <label class="field"><span>Price (${esc(state.cfg.currency)})</span><input id="pf-price" type="number" min="0" step="0.01" inputmode="decimal" value="${draft.price ? (draft.price / 100).toFixed(2) : ''}" required></label>
          <label class="field"><span>Sizes</span><input id="pf-sizes" value="${esc((draft.sizes || []).join(', '))}" placeholder="S, M, L, XL"><small>Separate with commas. Leave empty for one size.</small></label>
          <label class="field"><span>How many in stock</span><input id="pf-stock" type="number" min="0" step="1" inputmode="numeric" value="${draft.stock == null ? '' : draft.stock}"><small>Leave empty for no limit.</small></label>
          <label class="field full"><span>Description</span><textarea id="pf-desc">${esc(draft.description)}</textarea></label>
        </div>
        <label class="check"><input type="checkbox" id="pf-active" ${draft.active ? 'checked' : ''}> Show this product in the shop</label>
        <p class="form-error" id="pf-err" role="alert" hidden></p>
        <div class="row">${isNew ? '' : '<button type="button" class="btn btn-danger" id="pf-del">Delete product</button>'}<span class="spacer"></span><button class="btn" type="button" data-close>Cancel</button><button class="btn btn-primary" type="submit" id="pf-save">${isNew ? 'Add product' : 'Save changes'}</button></div>
      </form>`, { wide: true });
    $$('[data-close]', m).forEach((b) => b.addEventListener('click', closeModal));
    const err = $('#pf-err', m);
    const repaintImg = () => { $('#pf-img', m).innerHTML = productImage(draft); };
    $('#pf-file', m).addEventListener('change', async (e) => {
      const f = e.target.files[0]; if (!f) return;
      err.hidden = true;
      try {
        const dataUrl = await resizeImage(f);
        $('#pf-img', m).innerHTML = loading('Uploading…');
        draft.image = await API.admin.uploadImage(dataUrl);
        repaintImg();
      } catch (ex) { err.textContent = ex.message; err.hidden = false; repaintImg(); }
    });
    const noimg = $('#pf-noimg', m); if (noimg) noimg.addEventListener('click', () => { draft.image = null; repaintImg(); noimg.remove(); });
    const del = $('#pf-del', m);
    if (del) del.addEventListener('click', async () => {
      const ok = await confirmBox({ title: `Delete “${draft.name}”?`, body: 'It disappears from the shop and from customers’ bags. Past orders and receipts keep their details. To take it off sale for now, hide it instead.', yes: 'Delete product', danger: true });
      if (!ok) { editProduct(p, reload); return; }
      try { await API.admin.deleteProduct(draft.id); toast('Product deleted.'); state.products = []; reload(); } catch (ex) { toast(ex.message, { tone: 'bad' }); }
    });
    $('#pf', m).addEventListener('submit', async (e) => {
      e.preventDefault(); err.hidden = true;
      const name = $('#pf-name', m).value.trim(), price = Math.round(parseFloat($('#pf-price', m).value) * 100);
      const stockRaw = $('#pf-stock', m).value.trim();
      if (name.length < 2) { err.textContent = 'Give the product a name.'; err.hidden = false; return; }
      if (!Number.isFinite(price) || price <= 0) { err.textContent = 'Enter a price above zero.'; err.hidden = false; return; }
      if (stockRaw !== '' && (!/^\d+$/.test(stockRaw))) { err.textContent = 'Stock must be a whole number, or empty for no limit.'; err.hidden = false; return; }
      const payload = {
        ...draft, name, price, category: $('#pf-cat', m).value, description: $('#pf-desc', m).value.trim(),
        sizes: $('#pf-sizes', m).value.split(',').map((s) => s.trim()).filter(Boolean),
        stock: stockRaw === '' ? null : parseInt(stockRaw, 10), active: $('#pf-active', m).checked,
      };
      const b = $('#pf-save', m); busy(b, true, 'Saving…');
      try { await API.admin.saveProduct(payload); closeModal(); toast(isNew ? 'Product added to the shop.' : 'Product saved.'); state.products = []; reload(); } catch (ex) { busy(b, false); err.textContent = ex.message; err.hidden = false; }
    });
  }

  function curSym() {
    try { return new Intl.NumberFormat(state.cfg.locale || 'en-US', { style: 'currency', currency: state.cfg.currency }).formatToParts(1).find((x) => x.type === 'currency').value; } catch { return state.cfg.currency; }
  }

  async function viewAdminDelivery() {
    adminShell('delivery');
    const body = $('#admin-body');
    const sym = esc(curSym());
    const cedis = (minor) => (minor ? String(minor / 100) : '');
    const toMinor = (v) => { const n = parseFloat(v); return Number.isFinite(n) && n > 0 ? Math.round(n * 100) : 0; };
    let data = null;
    const filter = { q: '', region: '' };

    const formSettings = () => Delivery.settings({
      baseFee: toMinor($('#ds-base').value), perKm: toMinor($('#ds-km').value), minFee: toMinor($('#ds-min').value),
      maxFee: toMinor($('#ds-max').value), roundTo: toMinor($('#ds-round').value), freeOver: toMinor($('#ds-free').value), pickup: $('#ds-pickup').checked,
    });
    const paintExample = () => {
      const st = formSettings();
      $('#ds-example').innerHTML = `With these prices: ${[5, 20, 50, 200].map((km) => `${km} km costs <strong>${money(Delivery.zoneFee({ km }, st))}</strong>`).join(', ')}.`;
      paintRows(st);
    };
    const paintRows = (st) => {
      const ql = filter.q.trim().toLowerCase();
      const list = data.zones.filter((z) => (!filter.region || z.region === filter.region) && (!ql || z.name.toLowerCase().includes(ql)))
        .sort((a, b) => a.km - b.km);
      $('#z-count').textContent = `${list.length} of ${data.zones.length}`;
      $('#z-rows').innerHTML = list.length ? list.map((z) => `<tr class="clickable" data-z="${esc(z.id)}"><td><strong>${esc(z.name)}</strong></td><td>${esc(z.region)}</td><td class="r">${kmText(z.km)}</td>
        <td class="r">${money(Delivery.zoneFee(z, st))}${z.fee != null ? '<br><span class="small muted">fixed</span>' : ''}</td>
        <td>${z.active ? '<span class="pill pill-good">Shown</span>' : '<span class="pill pill-warn">Hidden</span>'}</td><td><button class="btn btn-sm" type="button" data-z="${esc(z.id)}">Edit</button></td></tr>`).join('')
        : '<tr><td colspan="6" class="muted">No locations match. Clear the search or add the location.</td></tr>';
      $$('tr[data-z]', body).forEach((tr) => tr.addEventListener('click', () => editZone(data.zones.find((z) => z.id === tr.dataset.z))));
    };
    const paint = () => {
      const st = data.settings;
      const regions = Array.from(new Set([...Delivery.REGIONS, ...data.zones.map((z) => z.region)]));
      body.innerHTML = `<form class="panel stack" id="dset" novalidate>
          <div><h2>Delivery prices</h2><p class="muted small" style="margin-top:4px">Each location's fee is the starting fee plus the price per km for its distance from your shop, rounded up. You can give any location its own fixed fee instead.</p></div>
          <div class="form-grid three">
            <label class="field"><span>Starting fee (${sym})</span><input id="ds-base" type="number" min="0" step="0.5" inputmode="decimal" value="${cedis(st.baseFee)}"></label>
            <label class="field"><span>Price per km (${sym})</span><input id="ds-km" type="number" min="0" step="0.1" inputmode="decimal" value="${cedis(st.perKm)}"></label>
            <label class="field"><span>Round up to the nearest (${sym})</span><input id="ds-round" type="number" min="0" step="1" inputmode="decimal" value="${cedis(st.roundTo)}"></label>
            <label class="field"><span>Lowest fee (${sym})</span><input id="ds-min" type="number" min="0" step="1" inputmode="decimal" value="${cedis(st.minFee)}"></label>
            <label class="field"><span>Highest fee (${sym}, optional)</span><input id="ds-max" type="number" min="0" step="1" inputmode="decimal" value="${cedis(st.maxFee)}" placeholder="No limit"></label>
            <label class="field"><span>Free delivery over (${sym}, optional)</span><input id="ds-free" type="number" min="0" step="1" inputmode="decimal" value="${cedis(st.freeOver)}" placeholder="Never free"></label>
          </div>
          <label class="check"><input type="checkbox" id="ds-pickup" ${st.pickup ? 'checked' : ''}> Customers can pick up at the shop for free</label>
          <p class="zone-note" id="ds-example" aria-live="polite"></p>
          <p class="form-error" id="ds-err" role="alert" hidden></p>
          <button class="btn btn-primary" style="width:fit-content" type="submit" id="ds-save">Save prices</button>
        </form>
        <section class="stack" style="margin-top:28px">
          <div class="row"><h2 style="font-size:1.15rem">Delivery locations</h2><span class="small muted" id="z-count"></span><span class="spacer"></span><button class="btn btn-primary btn-sm" type="button" id="z-add">${icon('plus')} Add location</button></div>
          <p class="small muted">Distances are estimated road distances from the shop. Change any that you know better. Customers only see locations marked Shown.</p>
          <div class="row">
            <label class="search" style="flex:1 1 220px">${icon('search')}<span class="sr-only">Search locations</span><input id="zf-q" type="search" placeholder="Search locations" value="${esc(filter.q)}"></label>
            <label class="sr-only" for="zf-region">Region</label>
            <select class="input" id="zf-region" style="width:auto;flex:0 1 220px"><option value="">All regions</option>${regions.map((r) => `<option ${r === filter.region ? 'selected' : ''}>${esc(r)}</option>`).join('')}</select>
          </div>
          <div class="table-wrap"><table class="table"><thead><tr><th>Location</th><th>Region</th><th class="r">Distance</th><th class="r">Delivery fee</th><th>Customers</th><th><span class="sr-only">Edit</span></th></tr></thead><tbody id="z-rows"></tbody></table></div>
        </section>`;
      $$('#dset input').forEach((i) => i.addEventListener('input', paintExample));
      $('#ds-pickup').addEventListener('change', paintExample);
      $('#zf-q').addEventListener('input', (e) => { filter.q = e.target.value; paintRows(formSettings()); });
      $('#zf-region').addEventListener('change', (e) => { filter.region = e.target.value; paintRows(formSettings()); });
      $('#z-add').addEventListener('click', () => editZone(null));
      $('#dset').addEventListener('submit', async (e) => {
        e.preventDefault();
        const err = $('#ds-err'); err.hidden = true;
        const st2 = formSettings();
        if (st2.maxFee && st2.maxFee < st2.minFee) { err.textContent = 'The highest fee must be more than the lowest fee.'; err.hidden = false; return; }
        const b = $('#ds-save'); busy(b, true, 'Saving…');
        try { data.settings = await API.admin.saveDeliverySettings(st2); state.delivery = null; busy(b, false); toast('Delivery prices saved. Customers see the new fees at checkout.'); paintExample(); } catch (ex) { busy(b, false); err.textContent = ex.message; err.hidden = false; }
      });
      paintExample();
    };
    const editZone = (z) => {
      const isNew = !z;
      const d = z || { name: '', region: 'Eastern', km: '', fee: null, active: true };
      const regions = Array.from(new Set([...Delivery.REGIONS, d.region]));
      const m = openModal(`<h2>${isNew ? 'Add a delivery location' : `Edit ${esc(d.name)}`}</h2>
        <form class="stack" id="zf" novalidate style="margin-top:18px">
          <div class="form-grid">
            <label class="field full"><span>Town or area</span><input id="zf-name" value="${esc(d.name)}" placeholder="e.g. Pokrom Nsaba"></label>
            <label class="field"><span>Region</span><select id="zf-reg">${regions.map((r) => `<option ${r === d.region ? 'selected' : ''}>${esc(r)}</option>`).join('')}</select></label>
            <label class="field"><span>Distance from the shop (km)</span><input id="zf-km" type="number" min="0" step="0.5" inputmode="decimal" value="${esc(d.km)}"></label>
            <label class="field full"><span>Fixed fee (${sym}, optional)</span><input id="zf-fee" type="number" min="0" step="1" inputmode="decimal" value="${d.fee != null ? esc(d.fee / 100) : ''}" placeholder="Leave empty to work it out from the distance"><small id="zf-calc"></small></label>
          </div>
          <label class="check"><input type="checkbox" id="zf-active" ${d.active ? 'checked' : ''}> Show this location to customers</label>
          <p class="form-error" id="zf-err" role="alert" hidden></p>
          <div class="row">${isNew ? '' : '<button type="button" class="btn btn-danger" id="zf-del">Delete</button>'}<span class="spacer"></span><button class="btn" type="button" data-close>Cancel</button><button class="btn btn-primary" type="submit" id="zf-save">${isNew ? 'Add location' : 'Save changes'}</button></div>
        </form>`);
      $$('[data-close]', m).forEach((b) => b.addEventListener('click', closeModal));
      const calc = () => { const km = parseFloat($('#zf-km', m).value); $('#zf-calc', m).textContent = Number.isFinite(km) ? `From the distance it would cost ${money(Delivery.zoneFee({ km }, data.settings))}.` : ''; };
      $('#zf-km', m).addEventListener('input', calc); calc();
      const del = $('#zf-del', m);
      if (del) del.addEventListener('click', async () => {
        const ok = await confirmBox({ title: `Delete ${d.name}?`, body: 'Customers will no longer be able to choose it. Past orders keep their delivery details. To stop offering it for now, hide it instead.', yes: 'Delete location', danger: true });
        if (!ok) { editZone(z); return; }
        try { await API.admin.deleteZone(d.id); toast('Location deleted.'); state.delivery = null; load(); } catch (ex) { toast(ex.message, { tone: 'bad' }); }
      });
      $('#zf', m).addEventListener('submit', async (e) => {
        e.preventDefault();
        const err = $('#zf-err', m); err.hidden = true;
        const name = $('#zf-name', m).value.trim(), km = parseFloat($('#zf-km', m).value), feeRaw = $('#zf-fee', m).value.trim();
        if (name.length < 2) { err.textContent = 'Enter the town or area name.'; err.hidden = false; return; }
        if (!Number.isFinite(km) || km < 0) { err.textContent = 'Enter the distance from the shop in km.'; err.hidden = false; return; }
        const fee = feeRaw === '' ? null : Math.round(parseFloat(feeRaw) * 100);
        if (fee != null && !(fee >= 0)) { err.textContent = 'Enter a fixed fee, or leave it empty.'; err.hidden = false; return; }
        const b = $('#zf-save', m); busy(b, true, 'Saving…');
        try {
          await API.admin.saveZone({ id: d.id, name, region: $('#zf-reg', m).value, km, fee, active: $('#zf-active', m).checked });
          closeModal(); toast(isNew ? `${name} added. Customers can choose it at checkout.` : `${name} saved.`); state.delivery = null; load();
        } catch (ex) { busy(b, false); err.textContent = ex.message; err.hidden = false; }
      });
    };
    const load = async () => {
      try { data = await API.admin.delivery(); } catch (err) { body.innerHTML = `<div class="empty"><h2>That didn't load</h2><p class="muted">${esc(err.message)}</p></div>`; return; }
      if (!$('#admin-body')) return;
      paint();
    };
    state.adminRefresh = null;
    load();
  }

  async function viewAdminCustomers() {
    adminShell('customers');
    const body = $('#admin-body');
    const load = async () => {
      let list;
      try { list = await API.admin.customers(); } catch (err) { body.innerHTML = `<div class="empty"><h2>That didn't load</h2><p class="muted">${esc(err.message)}</p></div>`; return; }
      if (!$('#admin-body')) return;
      if (!list.length) { body.innerHTML = '<div class="empty"><h2>No customers yet</h2><p class="muted">People who sign up on the site appear here.</p></div>'; return; }
      body.innerHTML = `<div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th>Contact</th><th>Joined</th><th class="r">Paid orders</th><th class="r">Total spent</th><th><span class="sr-only">Password</span></th></tr></thead><tbody>
        ${list.map((c) => `<tr><td><strong>${esc(c.name)}</strong>${c.city ? `<br><span class="small muted">${esc(c.city)}</span>` : ''}</td><td>${esc(c.email)}<br><span class="small muted">${esc(c.phone)}</span></td><td class="small">${esc(day(c.createdAt))}</td><td class="r">${c.orders}</td><td class="r">${money(c.spent)}</td><td><button class="btn btn-sm" data-reset="${esc(c.id)}" data-name="${esc(c.name)}">Reset password</button></td></tr>`).join('')}
      </tbody></table></div>`;
      $$('[data-reset]', body).forEach((b) => b.addEventListener('click', async () => {
        const ok = await confirmBox({ title: `Reset ${b.dataset.name}'s password?`, body: 'Their current password stops working. You get a temporary one to give them, and they can change it in their account.', yes: 'Reset password' });
        if (!ok) return;
        try {
          const pw = await API.admin.resetPassword(b.dataset.reset);
          openModal(`<h2>New temporary password</h2><p class="muted" style="margin:8px 0 16px">Give this to ${esc(b.dataset.name)} by phone or in person. They should change it after signing in.</p><p class="temp-pw">${esc(pw)}</p>`);
        } catch (ex) { toast(ex.message, { tone: 'bad' }); }
      }));
    };
    state.adminRefresh = load;
    load();
  }

  /* ---------- router ---------- */
  function route() {
    const h = decodeURIComponent(location.hash.slice(1));
    closeModal();
    if (!state.user) {
      stopLive(); stopAdminLive();
      if (h && h !== 'login' && h !== 'signup') state.afterLogin = h;
      viewAuth(h === 'login' || (h !== 'signup' && store.get('hasAccount', false)) ? 'login' : 'signup');
      return;
    }
    if (h === 'login' || h === 'signup') { location.hash = state.user.role === 'admin' ? 'admin' : 'shop'; return; }
    if (h !== state.lastHash) window.scrollTo(0, 0);
    state.lastHash = h;
    stopLive();
    const admin = h === 'admin' || h.startsWith('admin-');
    if (!admin) stopAdminLive();
    if (admin && state.user.role !== 'admin') { location.hash = 'shop'; return; }
    if (h.startsWith('order-')) return viewOrder(h.slice(6));
    if (h.startsWith('receipt-')) return viewReceipt(h.slice(8));
    if (h.startsWith('pay-')) return viewPay(h.slice(4));
    switch (h) {
      case 'bag': return viewBag();
      case 'checkout': return viewCheckout();
      case 'orders': return viewOrders();
      case 'account': return viewAccount();
      case 'admin': return viewAdminOrders();
      case 'admin-products': return viewAdminProducts();
      case 'admin-customers': return viewAdminCustomers();
      case 'admin-delivery': return viewAdminDelivery();
      default: return viewShop();
    }
  }

  async function boot() {
    try {
      state.cfg = await API.config();
      document.title = state.cfg.shopName;
      const params = new URLSearchParams(location.search);
      const pay = params.get('payment');
      if (pay) { state.flash = pay === 'success' ? 'paid' : 'failed'; history.replaceState(null, '', location.pathname + location.hash); }
      state.user = await API.me();
    } catch (err) {
      view.innerHTML = `<div class="wrap empty"><h2>The shop didn't load</h2><p class="muted">${esc(err.message)}</p><button class="btn btn-primary" id="reload">Try again</button></div>`;
      $('#reload').addEventListener('click', () => location.reload());
      return;
    }
    previewBar();
    window.addEventListener('hashchange', route);
    route();
  }
  boot();
})();
