/* Flat garment illustrations used when a product has no photo yet.
   Upload real photos from the owner dashboard to replace them. */
window.Art = (() => {
  let uid = 0;
  const HEX = /^#[0-9a-f]{3}([0-9a-f]{3})?$/i;
  const safe = (c, d) => (HEX.test(c || '') ? c : d);

  function shade(hex, amt) {
    let c = hex.replace('#', '');
    if (c.length === 3) c = c.split('').map((x) => x + x).join('');
    const n = parseInt(c, 16);
    let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    const t = amt < 0 ? 0 : 255, p = Math.abs(amt);
    r = Math.round((t - r) * p + r); g = Math.round((t - g) * p + g); b = Math.round((t - b) * p + b);
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  const wire = '#8C918E';
  const hanger = `<g fill="none" stroke="${wire}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M100 42v-7q0-6 6-8q7-2 7-9q0-8-8-8q-7 0-8 6"/><path d="M100 42L50 64h100Z"/></g>`;
  const clipHanger = `<g fill="none" stroke="${wire}" stroke-width="3" stroke-linecap="round"><path d="M100 30v-7q0-6 6-8q7-2 7-9q0-8-8-8q-7 0-8 6"/><path d="M56 32h88"/></g><rect x="66" y="29" width="8" height="14" rx="1.5" fill="${wire}"/><rect x="126" y="29" width="8" height="14" rx="1.5" fill="${wire}"/>`;

  const kinds = {
    shirt(c, a) {
      const d = shade(c, -0.28), b = shade(c, -0.4);
      return `${hanger}
      <path d="M78 58L60 64L32 146L52 153L66 110V214Q100 221 134 214V110L148 153L168 146L140 64L122 58Q100 70 78 58Z" fill="${c}" stroke="${d}" stroke-width="1.5" stroke-linejoin="round"/>
      <path d="M33 141L53 148L52 153L32 146Z" fill="${a}"/><path d="M167 141L147 148L148 153L168 146Z" fill="${a}"/>
      <path d="M78 58L100 82L88 92L72 64Z" fill="${a}" stroke="${d}" stroke-width="1.2" stroke-linejoin="round"/>
      <path d="M122 58L100 82L112 92L128 64Z" fill="${a}" stroke="${d}" stroke-width="1.2" stroke-linejoin="round"/>
      <path d="M100 82V216" stroke="${d}" stroke-width="1.4"/>
      ${[102, 126, 150, 174, 198].map((y) => `<circle cx="104" cy="${y}" r="2.3" fill="${b}"/>`).join('')}
      <path d="M110 104h18v17q-9 4-18 0Z" fill="none" stroke="${d}" stroke-width="1.2"/>`;
    },
    polo(c) {
      const d = shade(c, -0.2), dd = shade(c, -0.35), l = shade(c, 0.12);
      return `${hanger}
      <path d="M80 58L60 64L38 106L58 116L68 100V212Q100 218 132 212V100L142 116L162 106L140 64L120 58Q100 68 80 58Z" fill="${c}" stroke="${dd}" stroke-width="1.5" stroke-linejoin="round"/>
      <path d="M40 101L60 111L58 116L38 106Z" fill="${d}"/><path d="M160 101L140 111L142 116L162 106Z" fill="${d}"/>
      <path d="M68 205Q100 211 132 205V212Q100 218 68 212Z" fill="${d}"/>
      <path d="M80 58L100 76L120 58L125 66L100 86L75 66Z" fill="${l}" stroke="${dd}" stroke-width="1.2" stroke-linejoin="round"/>
      <rect x="96" y="76" width="8" height="36" fill="${d}"/>
      <circle cx="100" cy="88" r="2.2" fill="${l}"/><circle cx="100" cy="102" r="2.2" fill="${l}"/>`;
    },
    blazer(c, a, suit) {
      const d = shade(c, -0.22), dd = shade(c, -0.45);
      let fill = c, defs = '';
      if (suit) {
        const id = 'ps' + (++uid);
        defs = `<defs><pattern id="${id}" width="7" height="10" patternUnits="userSpaceOnUse"><rect width="7" height="10" fill="${c}"/><path d="M0.5 0V10" stroke="${shade(c, 0.22)}" stroke-width=".8"/></pattern></defs>`;
        fill = `url(#${id})`;
      }
      return `${defs}${hanger}
      <path d="M78 56L56 66L30 156L50 162L62 122V220H138V122L150 162L170 156L144 66L122 56Z" fill="${fill}" stroke="${dd}" stroke-width="1.5" stroke-linejoin="round"/>
      <path d="M82 56L100 126L118 56Q100 64 82 56Z" fill="${suit ? '#F4F5F2' : a}"/>
      ${suit ? `<path d="M95 61h10l-1.5 7h-7Z" fill="${shade(a, -0.2)}"/><path d="M96.5 68h7L106 112L100 121L94 112Z" fill="${a}"/>` : ''}
      <path d="M82 56L72 66L80 94L72 102L100 152V126Z" fill="${d}"/>
      <path d="M118 56L128 66L120 94L128 102L100 152V126Z" fill="${d}"/>
      <path d="M100 152Q103 196 92 220" fill="none" stroke="${dd}" stroke-width="1.3"/>
      <circle cx="100" cy="164" r="3.2" fill="${dd}"/><circle cx="99" cy="186" r="3.2" fill="${dd}"/>
      <rect x="67" y="184" width="22" height="5" rx="1" fill="${d}"/><rect x="111" y="184" width="22" height="5" rx="1" fill="${d}"/>
      <path d="M110 106l17-3" stroke="${dd}" stroke-width="3" stroke-linecap="round"/>`;
    },
    suit(c, a) { return kinds.blazer(c, a, true); },
    trousers(c) {
      const d = shade(c, -0.14), dd = shade(c, -0.3);
      return `${clipHanger}
      <path d="M64 40H136L142 222H110L100 94L90 222H58Z" fill="${c}" stroke="${dd}" stroke-width="1.5" stroke-linejoin="round"/>
      <path d="M64 40H136L136.5 51H63.5Z" fill="${d}"/>
      ${[74, 97, 122].map((x) => `<rect x="${x}" y="38" width="4" height="15" rx="1" fill="${dd}"/>`).join('')}
      <path d="M100 51V92" stroke="${dd}" stroke-width="1.2"/><path d="M100 51q9 18 3 40" fill="none" stroke="${dd}" stroke-width="1.2"/>
      <path d="M80 54L75 220M120 54L125 220" stroke="${d}" stroke-width="1.3"/>
      <path d="M67 52Q80 66 70 82M133 52Q120 66 130 82" fill="none" stroke="${dd}" stroke-width="1.2"/>`;
    },
    shoe(c, a) {
      const d = shade(c, -0.3), sole = a || shade(c, -0.5);
      return `
      <path d="M26 166C24 140 40 127 62 125L96 118C112 115 124 121 136 133C150 145 166 147 178 152C189 157 189 165 185 168Z" fill="${c}" stroke="${d}" stroke-width="1.5" stroke-linejoin="round"/>
      <path d="M22 166H189Q191 175 183 177H30Q22 177 22 169Z" fill="${sole}"/>
      <path d="M24 176H62V184H29Q24 184 24 180Z" fill="${shade(sole, -0.2)}"/>
      <path d="M62 125C58 141 60 156 68 166" fill="none" stroke="${d}" stroke-width="1.4"/>
      <path d="M150 146C146 156 150 163 157 167" fill="none" stroke="${d}" stroke-width="1.4"/>
      <path d="M96 119L124 143" stroke="${d}" stroke-width="2"/>
      ${[0, 1, 2, 3].map((i) => `<path d="M${101 + i * 6} ${117 + i * 6}l-7 7" stroke="#E9E2D8" stroke-width="1.6" stroke-linecap="round"/>`).join('')}
      <path d="M66 129C80 125 90 123 95 122" fill="none" stroke="${shade(c, 0.3)}" stroke-width="1" stroke-dasharray="2 3"/>
      <ellipse cx="166" cy="153" rx="10" ry="3" fill="#fff" opacity=".22" transform="rotate(14 166 153)"/>`;
    },
    loafer(c, a) {
      const d = shade(c, -0.3), sole = shade(a || c, -0.35);
      return `
      <path d="M26 166C24 146 36 134 56 132L100 128C118 126 132 132 146 140C160 147 172 149 180 153C189 158 189 165 185 168Z" fill="${c}" stroke="${d}" stroke-width="1.5" stroke-linejoin="round"/>
      <path d="M22 166H189Q191 174 183 176H30Q22 176 22 169Z" fill="${sole}"/>
      <path d="M24 175H60V182H29Q24 182 24 179Z" fill="${shade(sole, -0.2)}"/>
      <path d="M108 130C124 128 150 138 168 152" fill="none" stroke="${shade(c, 0.25)}" stroke-width="1.2" stroke-dasharray="2.5 3"/>
      <path d="M104 134C118 136 134 142 146 149" stroke="${d}" stroke-width="7" stroke-linecap="round"/>
      <ellipse cx="126" cy="140" rx="7" ry="2.2" fill="${shade(c, 0.35)}" transform="rotate(18 126 140)"/>`;
    },
    sneaker(c, a) {
      return `
      <path d="M26 162C24 138 38 125 60 123L98 115C114 113 126 123 138 135C152 147 170 147 180 152C190 158 190 165 186 167Z" fill="${c}" stroke="#C9CDC8" stroke-width="1.5" stroke-linejoin="round"/>
      <path d="M22 162H190V174Q190 183 182 183H30Q22 183 22 175Z" fill="#FFFFFF" stroke="#CDD1CC" stroke-width="1.5"/>
      <path d="M24 172H189" stroke="#DADDD8" stroke-width="1.2"/>
      <path d="M26 140C24 129 31 123 41 123L46 152Z" fill="${a}"/>
      <path d="M68 150C88 140 110 136 132 141" fill="none" stroke="${a}" stroke-width="5" stroke-linecap="round"/>
      ${[0, 1, 2, 3].map((i) => `<path d="M${102 + i * 6} ${116 + i * 6}l-7 7" stroke="#B9BEB8" stroke-width="1.8" stroke-linecap="round"/>`).join('')}`;
    },
    tie(c, a) {
      const id = 'st' + (++uid);
      return `<defs><pattern id="${id}" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(38)"><rect width="12" height="12" fill="${c}"/><rect width="12" height="3" fill="${a}"/></pattern></defs>
      <path d="M94 60H106L123 196L100 223L77 196Z" fill="url(#${id})" stroke="${shade(c, -0.35)}" stroke-width="1.3" stroke-linejoin="round"/>
      <path d="M89 32H111L106 60H94Z" fill="url(#${id})" stroke="${shade(c, -0.35)}" stroke-width="1.3" stroke-linejoin="round"/>
      <path d="M89 32H111L106 60H94Z" fill="#000" opacity=".16"/>`;
    },
    belt(c, a) {
      const st = shade(c, 0.3);
      return `
      <rect x="20" y="106" width="134" height="28" rx="3" fill="${c}"/>
      <path d="M150 106H178Q190 120 178 134H150Z" fill="${c}"/>
      <rect x="25" y="110" width="150" height="20" rx="2" fill="none" stroke="${st}" stroke-width="1" stroke-dasharray="3 3"/>
      ${[138, 152, 166].map((x) => `<circle cx="${x}" cy="120" r="2.6" fill="${shade(c, -0.55)}"/>`).join('')}
      <rect x="84" y="102" width="9" height="36" rx="2" fill="${shade(c, -0.25)}"/>
      <rect x="34" y="96" width="38" height="48" rx="8" fill="none" stroke="${a}" stroke-width="6"/>
      <path d="M40 120H72" stroke="${a}" stroke-width="4" stroke-linecap="round"/>`;
    },
    watch(c, a) {
      const dial = '#F6F5F0';
      const marks = Array.from({ length: 12 }, (_, i) => `<path d="M100 86V${i % 3 === 0 ? 93 : 90}" stroke="#2A2F33" stroke-width="${i % 3 === 0 ? 2.4 : 1.4}" transform="rotate(${i * 30} 100 120)"/>`).join('');
      return `
      <rect x="80" y="20" width="40" height="72" rx="10" fill="${c}"/>
      <rect x="80" y="148" width="40" height="74" rx="10" fill="${c}"/>
      <rect x="85" y="24" width="30" height="64" rx="7" fill="none" stroke="${shade(c, 0.35)}" stroke-width="1" stroke-dasharray="2.5 3"/>
      <rect x="85" y="152" width="30" height="66" rx="7" fill="none" stroke="${shade(c, 0.35)}" stroke-width="1" stroke-dasharray="2.5 3"/>
      ${[184, 196, 208].map((y) => `<circle cx="100" cy="${y}" r="2.2" fill="${shade(c, 0.4)}"/>`).join('')}
      <rect x="146" y="113" width="9" height="14" rx="2.5" fill="${a}"/>
      <circle cx="100" cy="120" r="48" fill="${a}" stroke="${shade(a, -0.28)}" stroke-width="2"/>
      <circle cx="100" cy="120" r="40" fill="${dial}"/>
      ${marks}
      <path d="M100 120V92" stroke="#2A2F33" stroke-width="2.6" stroke-linecap="round"/>
      <path d="M100 120L118 130" stroke="#2A2F33" stroke-width="3.6" stroke-linecap="round"/>
      <path d="M100 128V88" stroke="#7B2C2C" stroke-width="1" stroke-linecap="round" transform="rotate(200 100 120)"/>
      <circle cx="100" cy="120" r="3" fill="#2A2F33"/>`;
    },
  };

  function svg(art) {
    const a = art || {};
    const kind = kinds[a.kind] ? a.kind : 'shirt';
    const c = safe(a.color, '#C9CFCB'), acc = safe(a.accent, shade(c, -0.15));
    return `<svg viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">${kinds[kind](c, acc)}</svg>`;
  }

  return { svg, kinds: Object.keys(kinds), safeColor: safe };
})();
