/* Delivery pricing shared by the website and the server, so both always agree on the fee.
   Fee for a location = starting fee + price per km x distance from the shop, rounded up,
   kept between the minimum and maximum. A location can also have its own fixed fee. Amounts are in pesewas. */
(function (root, factory) {
  const m = factory();
  if (typeof module === 'object' && module.exports) module.exports = m; else root.Delivery = m;
}(typeof self !== 'undefined' ? self : this, () => {
  const DEFAULTS = { baseFee: 1500, perKm: 150, minFee: 2000, maxFee: 0, roundTo: 500, freeOver: 0, pickup: true };
  const NUMS = ['baseFee', 'perKm', 'minFee', 'maxFee', 'roundTo', 'freeOver'];

  function settings(s) {
    const o = { ...DEFAULTS, ...(s || {}) };
    NUMS.forEach((k) => { o[k] = Math.max(0, Math.round(Number(o[k]) || 0)); });
    o.pickup = o.pickup !== false && o.pickup !== 'false' && o.pickup !== 0;
    return o;
  }

  function zoneFee(zone, s) {
    if (!zone) return null;
    if (zone.fee != null && zone.fee !== '') return Math.max(0, Math.round(Number(zone.fee)));
    let f = s.baseFee + s.perKm * Math.max(0, Number(zone.km) || 0);
    if (s.roundTo > 0) f = Math.ceil(f / s.roundTo - 1e-9) * s.roundTo;
    if (s.minFee) f = Math.max(f, s.minFee);
    if (s.maxFee) f = Math.min(f, s.maxFee);
    return Math.round(f);
  }

  // choice is 'pickup' or a location. Returns null when the choice isn't available.
  function feeFor(choice, s, subtotal) {
    if (choice === 'pickup') return s.pickup ? 0 : null;
    const f = zoneFee(choice, s);
    if (f == null) return null;
    if (s.freeOver && subtotal >= s.freeOver) return 0;
    return f;
  }

  const REGIONS = ['Eastern', 'Greater Accra', 'Central', 'Ashanti', 'Western', 'Western North', 'Volta', 'Oti', 'Bono', 'Bono East', 'Ahafo', 'Northern', 'Savannah', 'North East', 'Upper East', 'Upper West'];

  return { DEFAULTS, settings, zoneFee, feeFor, REGIONS };
}));
