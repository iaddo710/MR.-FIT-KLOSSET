/* Preview backend: the same API the real server offers, kept in this browser so the shop can be
   clicked through before it is deployed. Payments are simulated; nothing leaves the browser. */
window.API = (() => {
  const KEY = 'mr-fit-klosset-preview-v5';
  const CFG = {
    shopName: 'Mr. Fit Klosset',
    tagline: 'Polos, shirts, matching sets and hoodies for men who like to look sharp.',
    currency: 'GHS', locale: 'en-GH',
    categories: ['Knit polos', 'Polo shirts', 'Shirts', 'Shirt and trouser sets', 'Hoodie sets', 'Trousers', 'Shoes', 'Accessories'],
    contactPhone: '0537945052', whatsapp: '233537945052', contactEmail: '', address: 'Teacher Mante, off Nsawam-Suhum Road, near the MTN pole',
    receiptNote: 'Thank you for shopping with us. Unworn items can be returned or exchanged within 14 days with this receipt.',
    logoSmall: 'brand/logo-128.png', logoLarge: 'brand/logo-256.png',
    paymentProvider: 'demo', paymentName: 'Test checkout', paymentMethods: 'Mobile Money or card',
  };
  const HOUR = 3600e3, DAYMS = 24 * HOUR;
  const iso = (t) => new Date(t).toISOString();
  const wait = (ms = 160) => new Promise((r) => setTimeout(r, ms));
  const clone = (x) => JSON.parse(JSON.stringify(x));
  const rand = (n, abc = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ') => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => abc[b % abc.length]).join('');
  const fail = (msg) => { throw new Error(msg); };
  let mem = null;

  async function hash(pw) {
    try {
      const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('mfk-preview:' + pw));
      return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('');
    } catch { return 'plain:' + pw; }
  }

  function seed() {
    const now = Date.now();
    const products = clone(window.__SEED_PRODUCTS__).map((p) => ({ ...p, active: true }));
    const P = Object.fromEntries(products.map((p) => [p.id, p]));
    const zones = clone(window.__SEED_LOCATIONS__).map((z) => ({ ...z, fee: null, active: true }));
    const deliverySettings = Delivery.settings({});
    const users = [
      { id: 'u-owner', role: 'admin', name: 'Owner', email: 'owner@example.com', phone: '', address: '', city: '', createdAt: iso(now - 120 * DAYMS), pw: null },
      { id: 'u-s1', role: 'customer', name: 'Kwabena Owusu', email: 'kwabena.o@example.com', phone: '+233 00 000 0181', address: 'House 12, near the Methodist church', city: 'Nsawam', zoneId: 'z-nsawam', createdAt: iso(now - 40 * DAYMS), pw: null },
      { id: 'u-s2', role: 'customer', name: 'Yaw Darko', email: 'yaw.darko@example.com', phone: '+233 00 000 0127', address: 'Behind the lorry station', city: 'Suhum', zoneId: 'z-suhum', createdAt: iso(now - 21 * DAYMS), pw: null },
      { id: 'u-s3', role: 'customer', name: 'Emmanuel Tetteh', email: 'e.tetteh@example.com', phone: '+233 00 000 0163', address: 'Blue gate, off the main road', city: 'Adoagyiri', zoneId: 'z-adoagyiri', createdAt: iso(now - 9 * DAYMS), pw: null },
    ];
    let seq = 1040;
    const mk = (user, lines, status, ago, extra = {}) => {
      const u = users.find((x) => x.id === user);
      const items = lines.map(([pid, size, qty]) => ({ productId: pid, name: P[pid].name, size, qty, price: P[pid].price, art: P[pid].art, image: P[pid].image }));
      const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
      const z = extra.pickup ? null : zones.find((x) => x.id === u.zoneId);
      const fee = Delivery.feeFor(z || 'pickup', deliverySettings, subtotal);
      const created = now - ago;
      const o = {
        id: ++seq, code: rand(8), userId: user, status, items, subtotal, deliveryFee: fee, total: subtotal + fee, currency: CFG.currency,
        delivery: z ? { method: 'delivery', zoneId: z.id, name: u.name, phone: u.phone, address: u.address, city: z.name, region: z.region, km: z.km, notes: '' }
          : { method: 'pickup', zoneId: 'pickup', name: u.name, phone: u.phone, address: '', city: '', notes: '' },
        createdAt: iso(created), updatedAt: iso(created), paidAt: null, receiptNo: null, paymentProvider: null, paymentLabel: null, paymentRef: null, paymentError: null,
        courier: '', trackingNo: '', events: [],
      };
      const flow = ORDER.slice(1, ORDER.indexOf(status) + 1);
      flow.forEach((s, i) => {
        const at = created + (i + 1) * (extra.gap || 20 * 60e3);
        if (s === 'paid') Object.assign(o, { paidAt: iso(at), receiptNo: receiptNo(o.id, at), paymentProvider: 'demo', paymentLabel: 'Test card (no real money)', paymentRef: 'TEST-' + rand(10) });
        o.events.push({ status: s, note: (extra.notes || {})[s] || '', at: iso(at) });
        o.updatedAt = iso(at);
      });
      Object.assign(o, extra.fields || {});
      return o;
    };
    const orders = [
      mk('u-s1', [['p-knit-polo-navy', 'L', 1], ['p-shirt-black-gold', 'L', 1]], 'delivered', 9 * DAYMS, { gap: 14 * HOUR, notes: { delivered: 'Received by K. Owusu at home.' }, fields: { courier: 'Our rider', trackingNo: '' } }),
      mk('u-s3', [['p-hoodie-olive', 'XL', 1]], 'shipped', 2 * DAYMS, { gap: 9 * HOUR, notes: { shipped: 'Your parcel left the shop this afternoon. The rider will call before arriving.' }, fields: { courier: 'Our rider', trackingNo: '' } }),
      mk('u-s2', [['p-set-baroque-brown', 'M', 1]], 'processing', 26 * HOUR, { gap: 2 * HOUR, pickup: true, notes: { processing: 'Trousers being shortened as requested. We will call you to collect.' } }),
      mk('u-s1', [['p-set-palm-green', 'M', 1], ['p-knit-polo-rust', 'M', 1]], 'paid', 2 * HOUR, { gap: 6 * 60e3 }),
      mk('u-s2', [['p-hoodie-navy', 'L', 1]], 'pending_payment', 35 * 60e3),
    ];
    orders.forEach((o) => { if (o.userId === 'u-s2' && o.status === 'processing') o.delivery.notes = 'Please shorten the trousers by 2 inches.'; });
    return { products, zones, deliverySettings, users, orders, session: null, lastCustomer: null, log: [], logSeq: 0, seq };
  }

  const ORDER = ['pending_payment', 'paid', 'processing', 'shipped', 'out_for_delivery', 'delivered'];
  const LABEL = { pending_payment: 'Awaiting payment', paid: 'Payment confirmed', processing: 'Being prepared', shipped: 'Shipped', out_for_delivery: 'Out for delivery', delivered: 'Delivered', cancelled: 'Cancelled' };
  const receiptNo = (id, t) => { const d = new Date(t); return `RCT-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}-${String(id).padStart(5, '0')}`; };

  function load() {
    try { const raw = localStorage.getItem(KEY); if (raw) return JSON.parse(raw); } catch { /* storage off */ }
    return null;
  }
  function db() { if (!mem) { mem = load() || seed(); save(); } return mem; }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(mem)); } catch { /* keep in memory */ } }
  function fresh() { const l = load(); if (l) mem = l; return db(); }

  const listeners = new Set();
  function emit(type, order) {
    const d = db();
    d.logSeq += 1;
    d.log.push({ n: d.logSeq, type, code: order.code });
    if (d.log.length > 60) d.log = d.log.slice(-60);
    save();
    listeners.forEach((fn) => fn());
  }
  window.addEventListener('storage', (e) => { if (e.key === KEY) { mem = null; db(); listeners.forEach((fn) => fn()); } });

  const me = () => { const d = db(); return d.users.find((u) => u.id === d.session) || null; };
  const pub = (u) => (u ? { id: u.id, role: u.role, name: u.name, email: u.email, phone: u.phone || '', address: u.address || '', city: u.city || '', zoneId: u.zoneId || '' } : null);
  const needUser = () => me() || fail('Please sign in again.');
  const needOwner = (opts) => { const u = needUser(); if (u.role !== 'admin' && !(opts && opts.asPreview)) fail('Only the shop owner can do that.'); return u; };
  function view(o) {
    const d = db(), u = d.users.find((x) => x.id === o.userId) || {};
    const out = clone(o);
    out.customer = { id: u.id, name: u.name, email: u.email, phone: u.phone };
    return out;
  }
  function findOrder(code, opts) {
    const u = needUser(), o = db().orders.find((x) => x.code === String(code).toUpperCase());
    if (!o || (o.userId !== u.id && u.role !== 'admin' && !(opts && opts.asPreview))) fail("We couldn't find that order. Check the order number and try again.");
    return o;
  }
  function event(o, status, note) { const at = iso(Date.now()); o.events.push({ status, note: note || '', at }); o.updatedAt = at; }
  function markPaid(o, label, ref) {
    const d = db(), now = Date.now();
    if (o.paidAt) return;
    o.paidAt = iso(now); o.receiptNo = receiptNo(o.id, now); o.paymentLabel = label; o.paymentRef = ref; o.paymentError = null;
    o.status = 'paid'; event(o, 'paid', '');
    o.items.forEach((i) => { const p = d.products.find((x) => x.id === i.productId); if (p && p.stock != null) p.stock = Math.max(0, p.stock - i.qty); });
  }
  const validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

  return {
    mode: 'preview',
    canPrint: false,
    async config() { await wait(60); return clone(CFG); },
    async me() { await wait(60); return pub(me()); },
    async signup(p) {
      await wait();
      const d = db(), email = String(p.email || '').trim().toLowerCase();
      if (String(p.name || '').trim().length < 2) fail('Enter your full name.');
      if (!validEmail(email)) fail('Enter a valid email address.');
      if (String(p.password || '').length < 8) fail('Your password needs at least 8 characters.');
      if (d.users.some((u) => u.email === email)) fail('An account with this email already exists. Sign in instead.');
      const u = { id: 'u-' + rand(10).toLowerCase(), role: 'customer', name: String(p.name).trim(), email, phone: String(p.phone || '').trim(), address: '', city: '', createdAt: iso(Date.now()), pw: await hash(p.password) };
      d.users.push(u); d.session = u.id; d.lastCustomer = u.id; save();
      return pub(u);
    },
    async login(p) {
      await wait();
      const d = db(), email = String(p.email || '').trim().toLowerCase();
      const u = d.users.find((x) => x.email === email);
      if (!u || !u.pw || u.pw !== await hash(p.password || '')) fail("That email and password don't match. Check them and try again.");
      d.session = u.id; if (u.role === 'customer') d.lastCustomer = u.id; save();
      return pub(u);
    },
    async logout() { const d = db(); d.session = null; save(); },
    async updateAccount(p) {
      await wait();
      const u = needUser();
      ['name', 'phone', 'address', 'city'].forEach((k) => { if (p[k] != null) u[k] = String(p[k]).trim().slice(0, 200); });
      if (p.zoneId != null) {
        const z = db().zones.find((x) => x.id === p.zoneId);
        if (p.zoneId && p.zoneId !== 'pickup' && !z) fail('Choose a delivery location from the list.');
        u.zoneId = p.zoneId; if (z) u.city = z.name;
      }
      save(); return pub(u);
    },
    async changePassword(p) {
      await wait();
      const u = needUser();
      if (u.pw && u.pw !== await hash(p.current || '')) fail('Your current password is not right.');
      if (String(p.next || '').length < 8) fail('Your new password needs at least 8 characters.');
      u.pw = await hash(p.next); save(); return { ok: true };
    },
    async products() { await wait(120); needUser(); return clone(fresh().products.filter((p) => p.active)); },
    async delivery() { await wait(80); needUser(); const d = fresh(); return { settings: Delivery.settings(d.deliverySettings), zones: clone(d.zones.filter((z) => z.active)).sort((a, b) => a.km - b.km) }; },
    async createOrder({ items, delivery }) {
      await wait(220);
      const u = needUser(), d = db();
      if (!Array.isArray(items) || !items.length) fail('Your bag is empty.');
      const ds = Delivery.settings(d.deliverySettings);
      const zid = String(delivery.zoneId || '');
      const zone = zid === 'pickup' ? null : d.zones.find((z) => z.id === zid && z.active);
      if (zid === 'pickup' && !ds.pickup) fail('Pickup at the shop is not available right now. Choose a delivery location.');
      if (zid !== 'pickup' && !zone) fail('Choose your delivery location from the list.');
      const clean = (v, n = 200) => String(v || '').trim().slice(0, n);
      if (zone && clean(delivery.address).length < 4) fail('Enter your house address or a landmark near you, so the rider can find you.');
      const lines = items.map((it) => {
        const p = d.products.find((x) => x.id === it.productId && x.active);
        if (!p) fail('One of the items in your bag is no longer available. Remove it and try again.');
        const qty = Math.max(1, Math.min(20, parseInt(it.qty, 10) || 1));
        if (p.sizes.length && !p.sizes.includes(it.size)) fail(`Choose a size for ${p.name}.`);
        if (p.stock != null && p.stock < qty) fail(p.stock === 0 ? `${p.name} has just sold out. Remove it from your bag to continue.` : `Only ${p.stock} of ${p.name} left. Lower the quantity to continue.`);
        return { productId: p.id, name: p.name, size: p.sizes.length ? it.size : '', qty, price: p.price, art: p.art, image: p.image };
      });
      const subtotal = lines.reduce((s, i) => s + i.price * i.qty, 0);
      const fee = Delivery.feeFor(zone || 'pickup', ds, subtotal);
      d.seq += 1;
      const now = iso(Date.now());
      const o = {
        id: d.seq, code: rand(8), userId: u.id, status: 'pending_payment', items: lines, subtotal, deliveryFee: fee, total: subtotal + fee, currency: CFG.currency,
        delivery: zone
          ? { method: 'delivery', zoneId: zone.id, name: clean(delivery.name, 100), phone: clean(delivery.phone, 40), address: clean(delivery.address), city: zone.name, region: zone.region, km: zone.km, notes: clean(delivery.notes, 500) }
          : { method: 'pickup', zoneId: 'pickup', name: clean(delivery.name, 100), phone: clean(delivery.phone, 40), address: '', city: '', notes: clean(delivery.notes, 500) },
        createdAt: now, updatedAt: now, paidAt: null, receiptNo: null, paymentProvider: 'demo', paymentLabel: null, paymentRef: null, paymentError: null, courier: '', trackingNo: '', events: [],
      };
      d.orders.push(o); save(); emit('created', o);
      return view(o);
    },
    async startPayment(code) { await wait(); findOrder(code); return { demo: true }; },
    async demoPay(code, outcome) {
      await wait(900);
      const o = findOrder(code);
      if (o.status === 'cancelled') fail('This order was cancelled, so it can no longer be paid.');
      if (outcome === 'success') { markPaid(o, 'Test card (no real money)', 'TEST-' + rand(10)); save(); emit('paid', o); }
      else { o.paymentError = 'The test card was declined. No money was taken.'; o.updatedAt = iso(Date.now()); save(); }
      return view(o);
    },
    async verifyPayment(code) { await wait(); return view(findOrder(code)); },
    async cancelOrder(code) {
      await wait();
      const o = findOrder(code);
      if (o.status !== 'pending_payment') fail('This order is already paid. Contact the shop to cancel it.');
      o.status = 'cancelled'; event(o, 'cancelled', 'Cancelled by you before payment.'); save(); emit('updated', o);
      return view(o);
    },
    async myOrders() { await wait(); const u = needUser(); return fresh().orders.filter((o) => o.userId === u.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(view); },
    async order(code) { await wait(100); fresh(); return view(findOrder(code)); },
    subscribeOrder(code, onOrder, onState) {
      let last = null;
      const tick = () => { try { fresh(); const o = view(findOrder(code)); const sig = o.updatedAt + o.status; if (sig !== last) { last = sig; onOrder(o); } } catch { /* signed out */ } };
      try { const o = findOrder(code); last = o.updatedAt + o.status; } catch { /* ignore */ }
      listeners.add(tick);
      const poll = setInterval(tick, 3000);
      setTimeout(() => onState && onState('live'), 300);
      return () => { listeners.delete(tick); clearInterval(poll); };
    },
    async saveFile(filename, bytes) {
      const dl = window.claude && window.claude.use ? await window.claude.use('downloads') : null;
      if (!dl) fail("Downloads aren't available in this preview window. Open the preview on its own page to save the PDF.");
      try { await dl.save({ filename, data: bytes }); return true; } catch (e) { if (e && e.code === 'declined') { const x = new Error('declined'); x.code = 'declined'; throw x; } fail("The PDF couldn't be saved here. Try again."); }
    },

    admin: {
      async summary() {
        await wait(); needOwner(); const d = fresh(), now = Date.now();
        const startToday = new Date(); startToday.setHours(0, 0, 0, 0);
        const paid = d.orders.filter((o) => o.paidAt && o.status !== 'cancelled');
        return {
          toFulfil: d.orders.filter((o) => ['paid', 'processing', 'shipped', 'out_for_delivery'].includes(o.status)).length,
          revenueToday: paid.filter((o) => new Date(o.paidAt) >= startToday).reduce((s, o) => s + o.total, 0),
          revenue30: paid.filter((o) => now - new Date(o.paidAt) < 30 * DAYMS).reduce((s, o) => s + o.total, 0),
          customers: d.users.filter((u) => u.role === 'customer').length,
        };
      },
      async orders() { await wait(); needOwner(); return fresh().orders.slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(view); },
      async updateOrder(code, p, opts) {
        await wait(220); needOwner(opts);
        const o = findOrder(code, { asPreview: true });
        const status = p.status, wasPaid = !!o.paidAt;
        if (!LABEL[status]) fail('Choose a status.');
        if (p.courier != null) o.courier = String(p.courier).slice(0, 80);
        if (p.trackingNo != null) o.trackingNo = String(p.trackingNo).slice(0, 80);
        if (status === 'pending_payment' && o.paidAt) fail('This order is already paid, so it cannot go back to awaiting payment.');
        if (status !== 'cancelled' && status !== 'pending_payment' && !o.paidAt) {
          if (status !== 'paid') fail('Mark the order as paid first. Orders are only prepared once payment is confirmed.');
          markPaid(o, 'Paid in shop (cash or transfer)', 'Recorded by shop');
          o.paymentProvider = 'manual';
          if (p.note) o.events[o.events.length - 1].note = p.note;
        } else if (status !== o.status || p.note) {
          if (status === 'cancelled' && o.status !== 'cancelled' && o.paidAt) {
            o.items.forEach((i) => { const pr = db().products.find((x) => x.id === i.productId); if (pr && pr.stock != null) pr.stock += i.qty; });
          }
          o.status = status; event(o, status, p.note);
        } else { o.updatedAt = iso(Date.now()); }
        save(); emit(!wasPaid && o.paidAt ? 'paid' : 'updated', o);
        return view(o);
      },
      async products() { await wait(); needOwner(); return clone(fresh().products); },
      async saveProduct(p) {
        await wait(220); needOwner();
        const d = db();
        const clean = {
          name: String(p.name || '').trim().slice(0, 120), category: String(p.category || 'Other').slice(0, 60), price: Math.round(Number(p.price) || 0),
          sizes: (p.sizes || []).map((s) => String(s).trim()).filter(Boolean).slice(0, 20), stock: p.stock == null ? null : Math.max(0, parseInt(p.stock, 10) || 0),
          description: String(p.description || '').slice(0, 1000), active: !!p.active, image: p.image || null, art: p.art || { kind: 'shirt' },
        };
        if (clean.name.length < 2) fail('Give the product a name.');
        if (clean.price <= 0) fail('Enter a price above zero.');
        let prod = p.id && d.products.find((x) => x.id === p.id);
        if (prod) Object.assign(prod, clean); else { prod = { id: 'p-' + rand(8).toLowerCase(), ...clean }; d.products.unshift(prod); }
        try { localStorage.setItem(KEY, JSON.stringify(d)); } catch { fail('This preview has run out of space for photos. Use a smaller photo, or reset the preview.'); }
        return clone(prod);
      },
      async deleteProduct(id) { await wait(); needOwner(); const d = db(); d.products = d.products.filter((x) => x.id !== id); save(); return { ok: true }; },
      async uploadImage(dataUrl) { await wait(300); needOwner(); return dataUrl; },
      async delivery() { await wait(); needOwner(); const d = fresh(); return { settings: Delivery.settings(d.deliverySettings), zones: clone(d.zones) }; },
      async saveDeliverySettings(st) {
        await wait(200); needOwner();
        const clean = Delivery.settings(st);
        if (clean.maxFee && clean.maxFee < clean.minFee) fail('The highest fee must be more than the lowest fee.');
        db().deliverySettings = clean; save(); return clone(clean);
      },
      async saveZone(z) {
        await wait(200); needOwner();
        const d = db(), name = String(z.name || '').trim().slice(0, 80), km = Number(z.km);
        if (name.length < 2) fail('Enter the town or area name.');
        if (!Number.isFinite(km) || km < 0) fail('Enter the distance from the shop in km.');
        const clean = { name, region: String(z.region || '').slice(0, 40), km: Math.round(km * 10) / 10, fee: z.fee == null ? null : Math.max(0, Math.round(z.fee)), active: z.active !== false };
        let zone = z.id && d.zones.find((x) => x.id === z.id);
        if (zone) Object.assign(zone, clean); else { zone = { id: 'z-' + rand(8).toLowerCase(), ...clean }; d.zones.push(zone); }
        save(); return clone(zone);
      },
      async deleteZone(id) { await wait(); needOwner(); const d = db(); d.zones = d.zones.filter((z) => z.id !== id); save(); return { ok: true }; },
      async customers() {
        await wait(); needOwner(); const d = fresh();
        return d.users.filter((u) => u.role === 'customer').map((u) => {
          const paid = d.orders.filter((o) => o.userId === u.id && o.paidAt && o.status !== 'cancelled');
          return { id: u.id, name: u.name, email: u.email, phone: u.phone, city: u.city, createdAt: u.createdAt, orders: paid.length, spent: paid.reduce((s, o) => s + o.total, 0) };
        }).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      },
      async resetPassword(id) {
        await wait(); needOwner();
        const u = db().users.find((x) => x.id === id) || fail('Customer not found.');
        const temp = rand(4) + '-' + rand(4);
        u.pw = await hash(temp); save(); return temp;
      },
      subscribe(onEvent, onState) {
        let seen = db().logSeq;
        const tick = () => {
          const d = fresh();
          const news = d.log.filter((e) => e.n > seen);
          if (!news.length) return;
          seen = d.logSeq;
          news.forEach((e) => {
            const o = d.orders.find((x) => x.code === e.code);
            const u = o && d.users.find((x) => x.id === o.userId);
            onEvent({ type: e.type, code: e.code, customer: u ? u.name : '', total: o ? o.total : 0 });
          });
        };
        listeners.add(tick);
        const poll = setInterval(tick, 3000);
        setTimeout(() => onState && onState('live'), 300);
        return () => { listeners.delete(tick); clearInterval(poll); };
      },
    },

    preview: {
      async switchTo(who) {
        const d = db();
        if (who === 'owner') d.session = 'u-owner';
        else d.session = d.lastCustomer && d.users.some((u) => u.id === d.lastCustomer) ? d.lastCustomer : null;
        save();
        return pub(me());
      },
      reset() { mem = null; try { localStorage.removeItem(KEY); } catch { /* ignore */ } },
    },
  };
})();
