// Bundles the storefront into one self-contained HTML file that runs with the in-browser preview backend.
// Usage: node preview/build.mjs  ->  preview/dist/preview.html
import { readFileSync, writeFileSync, mkdirSync, cpSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFileSync(join(root, p), 'utf8');
const safeScript = (s) => s.replace(/<\/script/gi, '<\\/script');

let html = read('public/index.html');
const seed = JSON.stringify(JSON.parse(read('seed/products.json')));
const places = JSON.stringify(JSON.parse(read('seed/locations.json')));

const put = (tag, content) => { if (!html.includes(tag)) throw new Error('Missing ' + tag); html = html.replace(tag, () => content); };
put('<link rel="stylesheet" href="styles.css">', `<style>\n${read('public/styles.css')}\n</style>`);
put('<script src="art.js"></script>', `<script>\n${safeScript(read('public/art.js'))}\n</script>`);
put('<script src="delivery.js"></script>', `<script>\n${safeScript(read('public/delivery.js'))}\n</script>`);
put('<script src="api.js"></script>', `<script>window.__SEED_PRODUCTS__ = ${seed}; window.__SEED_LOCATIONS__ = ${places};</script>\n  <script>\n${safeScript(read('preview/api-preview.js'))}\n</script>`);
put('<script src="receipt.js"></script>', `<script>\n${safeScript(read('public/receipt.js'))}\n</script>`);
put('<script src="app.js"></script>', `<script>\n${safeScript(read('public/app.js'))}\n</script>`);
// Artifact pages may load libraries only from approved CDNs, so point jsPDF at cdnjs (same version as public/vendor).
put('<script src="vendor/jspdf.umd.min.js" defer></script>', '<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>');

if (/src="(art|api|receipt|app|delivery)\.js"|href="styles\.css"/.test(html)) throw new Error('A local file was not inlined');
mkdirSync(join(root, 'preview/dist'), { recursive: true });
writeFileSync(join(root, 'preview/dist/preview.html'), html);
// Product photos are published next to the page and loaded by relative path.
cpSync(join(root, 'public/products'), join(root, 'preview/dist/products'), { recursive: true });
cpSync(join(root, 'public/brand'), join(root, 'preview/dist/brand'), { recursive: true });
console.log('Wrote preview/dist/preview.html', (html.length / 1024).toFixed(1) + ' KB');
