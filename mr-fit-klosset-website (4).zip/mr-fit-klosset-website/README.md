# Mr. Fit Klosset website

An all-in-one shop for a menswear boutique:

- **Sign-up wall.** Customers create an account (name, email, phone, password) before they can see the shop.
- **Shop.** Categories, search, sizes (S–XXL, 38R–46R, waist 30–38, UK shoe sizes), quantity and a bag.
- **Delivery priced by distance.** Customers pick their town from 140 locations across all 16 regions (searchable), and the fee is worked out from its distance to the shop. They can also choose free pickup at the shop.
- **Checkout and payment.** Delivery details, then payment with Mobile Money or card on Paystack's secure page. Card details and MoMo PINs never touch your server.
- **Receipt.** Issued automatically the moment a payment is confirmed, with a receipt number. Customers can print it or download it as a PDF.
- **Live order tracking.** Order placed → Payment confirmed → Being prepared → Shipped → Out for delivery → Delivered. When you update an order, the customer's tracking page changes instantly, with your courier, tracking number and any message you add.
- **Owner dashboard.** New paid orders appear live. Move orders along with one tap, add and edit products with photos, set stock, see customers and reset a customer's password.

It works on phones and computers, in light and dark mode.

---

## 1. Try it on your computer (10 minutes)

1. Install **Node.js 22.13 or newer** from nodejs.org.
2. Open a terminal in this folder and run:
   ```
   npm install
   cp .env.example .env
   ```
   (On Windows use `copy .env.example .env`.)
3. Open `.env` in a text editor. Set at least `SHOP_NAME`, `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
4. Start the shop:
   ```
   npm start
   ```
5. Open http://localhost:3000. Sign up as a customer to shop. Sign in with your `ADMIN_EMAIL` and `ADMIN_PASSWORD` to open the **Owner dashboard**.

The shop starts in **test mode** (`PAYMENT_PROVIDER=demo`): checkout shows a test payment screen and no money moves. It also starts with your 29 products and their photos. Check the prices and sizes under **Owner dashboard → Products**, and add new pieces there with a photo.

## 2. Set up real payments (Paystack, for Ghana)

Paystack lets your customers pay with **MTN MoMo, Telecel Cash, AirtelTigo Money or card**, in cedis, on Paystack's own secure page.

1. Create and verify your business account at paystack.com (choose Ghana).
2. In the Paystack dashboard, go to Settings → API Keys & Webhooks.
3. Copy your **secret key** into `.env` as `PAYSTACK_SECRET_KEY`, and set `PAYMENT_PROVIDER=paystack`.
4. Set the **Webhook URL** to `https://YOUR-DOMAIN/webhooks/paystack`.

Use the **test secret key** (`sk_test_...`) first and try a few orders. When everything works, swap in the live key (`sk_live_...`).

The webhook matters: if a customer pays with MoMo and closes their browser before returning to your site, the webhook still marks the order paid and issues the receipt.

(The site also supports Stripe, for shops outside Paystack's countries: set `PAYMENT_PROVIDER=stripe`, `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET`, with a webhook to `https://YOUR-DOMAIN/webhooks/stripe` for `checkout.session.completed`.)

## 3. Put it online

You need a Node.js host that keeps files between restarts (a "persistent disk" or "volume"), because your orders, customers and product photos are saved in the `data` folder. Render, Railway, Fly.io or any small VPS will work.

On the host:
- Build command: `npm install`. Start command: `npm start`.
- Add every setting from your `.env` as an environment variable, plus:
  - `NODE_ENV=production`
  - `PUBLIC_URL=https://your-domain.com`
  - `DATA_DIR` pointing at the persistent disk (for example `/var/data`)
  - `TZ=Africa/Accra` so "Paid today" matches your day
- Connect your domain and make sure it uses **https**.

For safety, the server refuses to start in test mode when `NODE_ENV=production`, so customers can't place "paid" orders without real money. Set `ALLOW_TEST_PAYMENTS=true` only while you are still testing.

**Backups:** copy the `data` folder (it holds `shop.db` and the `uploads` photos) somewhere safe regularly.

## 4. Running the shop day to day

- **New orders** appear on the Owner dashboard under **To fulfil**, with a pop-up the moment one is paid.
- Open an order to see the customer's phone, address, sizes and notes. Tap **Mark as "Being prepared"**, then **Shipped** (add the courier and tracking number), **Out for delivery** and **Delivered**. Each tap updates the customer's tracking page instantly. Add a message whenever it helps ("Trousers hemmed to 31 inches").
- **Paid in cash or by MoMo outside the site?** Choose "Payment confirmed (paid in cash or transfer)" on an unpaid order. It issues a receipt marked as paid in shop.
- **Cancelling** a paid order puts the stock back. Refund the customer from your Paystack dashboard.
- **Stock** goes down automatically when an order is paid. A product at 0 shows "Sold out". Leave stock empty for no limit.
- **Customer forgot their password?** Customers → Reset password gives you a temporary one to pass on. They can change it under Account.
- **You forgot the owner password?** Set `RESET_ADMIN_PASSWORD=true`, restart, then set it back to `false`.

## Delivery fees

Under **Owner dashboard → Delivery** you control:
- **Prices:** starting fee, price per km, rounding, lowest and highest fee, and an optional free-delivery amount. The page shows what 5, 20, 50 and 200 km cost before you save.
- **Locations:** 140 towns and areas are already loaded with an estimated road distance from the shop. Correct any distance you know better, give a town a fixed fee (for example a bus-station drop-off price for far regions), hide a town, or add new ones such as nearby villages.
- **Pickup:** switch free pickup at the shop on or off.

For pickup orders, the tracking steps change to "Ready for pickup" and "Collected".

## Settings reference

All settings live in `.env` (see `.env.example` for every option): shop name, tagline, address, phone and WhatsApp number, email, receipt note, categories, currency and number format, starting delivery prices, owner login, payment provider and keys.

## What's inside

| Path | What it is |
| --- | --- |
| `server.js` | The web server: accounts, products, orders, payments, receipts, owner tools |
| `lib/` | Database, passwords and sessions, payment providers, live updates |
| `public/` | The website customers and you use (one page, works on any device) |
| `seed/products.json` and `public/products/` | Your products and photos, added on first start |
| `seed/locations.json` | The delivery locations and distances added on first start |
| `preview/` | Builds the clickable preview with sample data (`npm run build:preview`) |

Security built in: passwords stored as scrypt hashes, sign-in cookies that scripts can't read, prices and stock always checked on the server, every payment confirmed directly with the provider and checked against the order total, signed webhooks, blocked cross-site form posts, a strict content security policy, and photo uploads checked to be real images.

## Good next steps

- Order and receipt emails: add an email service (for example Postmark, Resend or SendGrid) and send the receipt when an order is paid.
- WhatsApp or SMS updates when an order ships.
- Discount codes, and size guides per category.
