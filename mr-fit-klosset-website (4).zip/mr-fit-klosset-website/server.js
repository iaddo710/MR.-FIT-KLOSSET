'use strict';
// Menswear boutique: storefront, accounts, orders, payments, receipts and live order tracking.
try { process.loadEnvFile(); } catch { /* no .env file: use real environment variables */ }

const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const express = require('express');
const { open, seedProducts, seedZones } = require('./lib/db');
const Delivery = require('./public/delivery.js');
const auth = require('./lib/auth');
const live = require('./lib/live');
const payments = require('./lib/payments');

const env = process.env;
const ROOT = __dirname;
const DATA = path.resolve(env.DATA_DIR || path.join(ROOT, 'data'));
const UPLOADS = path.join(DATA, 'uploads');
fs.mkdirSync(UPLOADS, { recursive: true });

/* ---------------- settings ---------------- */
const minor = (v, d) => { const n = parseFloat(v); return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) : d; };
const pay = payments.pick(env);
const CFG = {
  shopName: env.SHOP_NAME || 'Mr. Fit Klosset',
  tagline: env.SHOP_TAGLINE || 'Polos, shirts, matching sets and hoodies for men who like to look sharp.',
  currency: (env.CURRENCY || 'GHS').toUpperCase(),
  locale: env.LOCALE || 'en-GH',
  categories: (env.CATEGORIES || 'Knit polos,Polo shirts,Shirts,Shirt and trouser sets,Hoodie sets,Trousers,Shoes,Accessories').split(',').map((s) => s.trim()).filter(Boolean),
  contactPhone: env.CONTACT_PHONE || '0537945052',
  whatsapp: String(env.WHATSAPP_NUMBER ?? '233537945052').replace(/\D/g, ''),
  contactEmail: env.CONTACT_EMAIL || '',
  address: env.SHOP_ADDRESS || 'Teacher Mante, off Nsawam-Suhum Road, near the MTN pole',
  receiptNote: env.RECEIPT_NOTE || 'Thank you for shopping with us. Unworn items can be returned or exchanged within 14 days with this receipt.',
  logoSmall: env.LOGO_SMALL ?? 'brand/logo-128.png',
  logoLarge: env.LOGO_LARGE ?? 'brand/logo-256.png',
  paymentProvider: pay.id,
  paymentName: pay.name,
  paymentMethods: env.PAYMENT_METHODS || (pay.id !== 'stripe' && (env.CURRENCY || 'GHS').toUpperCase() === 'GHS' ? 'Mobile Money or card' : 'card'),
};

if (pay.id === 'demo' && env.NODE_ENV === 'production' && env.ALLOW_TEST_PAYMENTS !== 'true') {
  console.error('\nRefusing to start: the shop is in test-payment mode on a live server, so anyone could "pay" without money.\n'
    + 'Set PAYMENT_PROVIDER=paystack or stripe with your secret key, or set ALLOW_TEST_PAYMENTS=true while you are still testing.\n');
  process.exit(1);
}

/* ---------------- database ---------------- */
const db = open(DATA);
const seeded = seedProducts(db, path.join(ROOT, 'seed', 'products.json'));
const seededZones = seedZones(db, path.join(ROOT, 'seed', 'locations.json'));
const sessions = auth.makeSessions(db);

const q = {
  userById: db.prepare('SELECT * FROM users WHERE id = ?'),
  userByEmail: db.prepare('SELECT * FROM users WHERE email = ?'),
  insertUser: db.prepare('INSERT INTO users (id, role, name, email, phone, address, city, pw, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'),
  updateUser: db.prepare('UPDATE users SET name = ?, phone = ?, address = ?, city = ?, zone_id = ? WHERE id = ?'),
  zonesActive: db.prepare('SELECT * FROM delivery_zones WHERE active = 1 ORDER BY km, name'),
  zonesAll: db.prepare('SELECT * FROM delivery_zones ORDER BY km, name'),
  zoneById: db.prepare('SELECT * FROM delivery_zones WHERE id = ?'),
  insertZone: db.prepare('INSERT INTO delivery_zones (id, name, region, km, fee, active) VALUES (?, ?, ?, ?, ?, ?)'),
  updateZone: db.prepare('UPDATE delivery_zones SET name = ?, region = ?, km = ?, fee = ?, active = ? WHERE id = ?'),
  deleteZone: db.prepare('DELETE FROM delivery_zones WHERE id = ?'),
  getSetting: db.prepare('SELECT value FROM settings WHERE key = ?'),
  putSetting: db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'),
  setPw: db.prepare('UPDATE users SET pw = ? WHERE id = ?'),
  setRole: db.prepare('UPDATE users SET role = ? WHERE id = ?'),
  customers: db.prepare(`SELECT u.id, u.name, u.email, u.phone, u.city, u.created_at,
      (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id AND o.paid_at IS NOT NULL AND o.status != 'cancelled') AS orders,
      (SELECT COALESCE(SUM(total), 0) FROM orders o WHERE o.user_id = u.id AND o.paid_at IS NOT NULL AND o.status != 'cancelled') AS spent
    FROM users u WHERE u.role = 'customer' ORDER BY u.created_at DESC`),
  countCustomers: db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'customer'"),

  productsActive: db.prepare('SELECT * FROM products WHERE active = 1 ORDER BY created_at DESC'),
  productsAll: db.prepare('SELECT * FROM products ORDER BY created_at DESC'),
  productById: db.prepare('SELECT * FROM products WHERE id = ?'),
  insertProduct: db.prepare(`INSERT INTO products (id, name, category, price, sizes, stock, description, image, art, active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`),
  updateProduct: db.prepare('UPDATE products SET name = ?, category = ?, price = ?, sizes = ?, stock = ?, description = ?, image = ?, art = ?, active = ? WHERE id = ?'),
  deleteProduct: db.prepare('DELETE FROM products WHERE id = ?'),
  takeStock: db.prepare('UPDATE products SET stock = MAX(0, stock - ?) WHERE id = ? AND stock IS NOT NULL'),
  returnStock: db.prepare('UPDATE products SET stock = stock + ? WHERE id = ? AND stock IS NOT NULL'),

  orderByCode: db.prepare('SELECT * FROM orders WHERE code = ?'),
  orderById: db.prepare('SELECT * FROM orders WHERE id = ?'),
  ordersOfUser: db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 200'),
  ordersAll: db.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 500'),
  insertOrder: db.prepare(`INSERT INTO orders (code, user_id, status, items, subtotal, delivery_fee, total, currency, delivery, payment_provider, created_at, updated_at)
    VALUES (?, ?, 'pending_payment', ?, ?, ?, ?, ?, ?, ?, ?, ?)`),
  setSession: db.prepare('UPDATE orders SET payment_session = ?, payment_provider = ?, payment_error = NULL, updated_at = ? WHERE id = ?'),
  setPayError: db.prepare('UPDATE orders SET payment_error = ?, updated_at = ? WHERE id = ?'),
  setPaid: db.prepare(`UPDATE orders SET status = 'paid', payment_provider = ?, payment_label = ?, payment_ref = ?, paid_at = ?, receipt_no = ?, payment_error = NULL, updated_at = ? WHERE id = ?`),
  setStatus: db.prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?'),
  setShipping: db.prepare('UPDATE orders SET courier = ?, tracking_no = ?, updated_at = ? WHERE id = ?'),
  events: db.prepare('SELECT status, note, at FROM order_events WHERE order_id = ? ORDER BY id'),
  addEvent: db.prepare('INSERT INTO order_events (order_id, status, note, at) VALUES (?, ?, ?, ?)'),
  countStatus: db.prepare("SELECT COUNT(*) AS n FROM orders WHERE status IN ('paid', 'processing', 'shipped', 'out_for_delivery')"),
  revenueSince: db.prepare("SELECT COALESCE(SUM(total), 0) AS s FROM orders WHERE paid_at IS NOT NULL AND paid_at >= ? AND status != 'cancelled'"),
};

/* ---------------- owner account ---------------- */
(function ensureOwner() {
  const email = String(env.ADMIN_EMAIL || '').trim().toLowerCase();
  if (!email || !env.ADMIN_PASSWORD) {
    console.warn('No owner account configured. Set ADMIN_EMAIL and ADMIN_PASSWORD in .env, then restart.');
    return;
  }
  const u = q.userByEmail.get(email);
  if (!u) {
    q.insertUser.run(newId('u_'), 'admin', env.ADMIN_NAME || 'Owner', email, '', '', '', auth.hashPassword(env.ADMIN_PASSWORD), now());
    console.log(`Owner account created for ${email}.`);
  } else {
    if (u.role !== 'admin') q.setRole.run('admin', u.id);
    if (env.RESET_ADMIN_PASSWORD === 'true') { q.setPw.run(auth.hashPassword(env.ADMIN_PASSWORD), u.id); console.log('Owner password reset from ADMIN_PASSWORD.'); }
  }
}());

/* ---------------- helpers ---------------- */
function now() { return new Date().toISOString(); }
function newId(prefix) { return prefix + crypto.randomBytes(8).toString('hex'); }
const ALPHA = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
const randCode = (n) => Array.from(crypto.randomBytes(n), (b) => ALPHA[b % ALPHA.length]).join('');
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const fail = (msg, status = 400) => { throw new HttpError(status, msg); };
const str = (v, max = 200) => String(v ?? '').trim().slice(0, max);
const validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
const h = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const baseUrl = (req) => (env.PUBLIC_URL ? env.PUBLIC_URL.replace(/\/+$/, '') : `${req.protocol}://${req.get('host')}`);
const receiptNo = (id, iso) => `RCT-${iso.slice(0, 10).replace(/-/g, '')}-${String(id).padStart(5, '0')}`;
const STATUSES = ['pending_payment', 'paid', 'processing', 'shipped', 'out_for_delivery', 'delivered', 'cancelled'];
const LABEL = { pending_payment: 'Awaiting payment', paid: 'Payment confirmed', processing: 'Being prepared', shipped: 'Shipped', out_for_delivery: 'Out for delivery', delivered: 'Delivered', cancelled: 'Cancelled' };
const ART_KINDS = ['shirt', 'polo', 'blazer', 'suit', 'trousers', 'shoe', 'loafer', 'sneaker', 'tie', 'belt', 'watch'];
const HEX = /^#[0-9a-f]{3}([0-9a-f]{3})?$/i;

const pubUser = (u) => (u ? { id: u.id, role: u.role, name: u.name, email: u.email, phone: u.phone, address: u.address, city: u.city, zoneId: u.zone_id || '' } : null);
const zoneView = (z) => ({ id: z.id, name: z.name, region: z.region, km: z.km, fee: z.fee, active: !!z.active });

// Delivery prices: what the owner saved in the dashboard, else .env, else built-in defaults.
const DELIVERY_ENV = {
  baseFee: minor(env.DELIVERY_BASE_FEE, Delivery.DEFAULTS.baseFee), perKm: minor(env.DELIVERY_PER_KM, Delivery.DEFAULTS.perKm),
  minFee: minor(env.DELIVERY_MIN_FEE, Delivery.DEFAULTS.minFee), maxFee: minor(env.DELIVERY_MAX_FEE, 0),
  roundTo: minor(env.DELIVERY_ROUND_TO, Delivery.DEFAULTS.roundTo), freeOver: minor(env.FREE_DELIVERY_OVER, 0),
  pickup: env.ALLOW_PICKUP !== 'false',
};
function deliverySettings() {
  const row = q.getSetting.get('delivery');
  let saved = {};
  try { saved = row ? JSON.parse(row.value) : {}; } catch { saved = {}; }
  return Delivery.settings({ ...DELIVERY_ENV, ...saved });
}
const product = (r) => ({ id: r.id, name: r.name, category: r.category, price: r.price, sizes: JSON.parse(r.sizes || '[]'), stock: r.stock, description: r.description, image: r.image, art: r.art ? JSON.parse(r.art) : null, active: !!r.active });

function orderView(r) {
  const u = q.userById.get(r.user_id) || {};
  return {
    code: r.code, status: r.status, items: JSON.parse(r.items), subtotal: r.subtotal, deliveryFee: r.delivery_fee, total: r.total, currency: r.currency,
    delivery: JSON.parse(r.delivery), customer: { id: u.id, name: u.name, email: u.email, phone: u.phone },
    paymentProvider: r.payment_provider, paymentLabel: r.payment_label, paymentRef: r.payment_ref, paymentError: r.payment_error,
    paidAt: r.paid_at, receiptNo: r.receipt_no, courier: r.courier, trackingNo: r.tracking_no,
    createdAt: r.created_at, updatedAt: r.updated_at, events: q.events.all(r.id),
  };
}

function ownOrder(req) {
  const r = q.orderByCode.get(str(req.params.code, 20).toUpperCase());
  if (!r || (r.user_id !== req.user.id && req.user.role !== 'admin')) fail("We couldn't find that order. Check the order number and try again.", 404);
  return r;
}

function broadcast(orderId, type) {
  const v = orderView(q.orderById.get(orderId));
  live.orderChanged(v);
  live.adminEvent({ type, code: v.code, customer: v.customer.name, total: v.total });
  return v;
}

// Marks an order paid exactly once, after the amount and currency check out.
function markPaid(orderId, { provider, label, ref, amount, currency }) {
  let became = false;
  db.tx(() => {
    const o = q.orderById.get(orderId);
    if (!o || o.paid_at) return;
    if (amount != null && (Number(amount) < o.total || String(currency || '').toUpperCase() !== o.currency)) {
      console.error(`[payments] Order ${o.code}: paid ${amount} ${currency}, expected ${o.total} ${o.currency}. Not marked paid.`);
      q.setPayError.run('The amount paid did not match this order. Please contact the shop with your payment reference.', now(), o.id);
      return;
    }
    const t = now();
    q.setPaid.run(provider, label, ref, t, receiptNo(o.id, t), t, o.id);
    q.addEvent.run(o.id, 'paid', o.status === 'cancelled' ? 'Your payment arrived after the order was cancelled, so we reopened it.' : '', t);
    JSON.parse(o.items).forEach((i) => q.takeStock.run(i.qty, i.productId));
    became = true;
  });
  if (became) broadcast(orderId, 'paid');
  return became;
}

// Asks the payment provider about a payment and records the result.
async function confirm(session) {
  if (!session || pay.id === 'demo') return null;
  const r = await pay.verify(session);
  const o = r.orderCode ? q.orderByCode.get(String(r.orderCode).toUpperCase()) : null;
  if (!o) return null;
  if (r.paid) markPaid(o.id, { provider: pay.id, label: r.label, ref: r.ref, amount: r.amount, currency: r.currency });
  else if (r.error && !o.paid_at) { q.setPayError.run(r.error, now(), o.id); }
  return o.code;
}

/* ---------------- app ---------------- */
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

const CSP = [
  "default-src 'self'", "script-src 'self'", "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com", "img-src 'self' data: blob:", "connect-src 'self'",
  "frame-ancestors 'none'", "base-uri 'self'", "form-action 'self'", "object-src 'none'",
].join('; ');
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'DENY', 'Content-Security-Policy': CSP });
  next();
});

// Webhooks need the raw body to check the provider's signature.
app.post('/webhooks/:provider', express.raw({ type: '*/*', limit: '1mb' }), h(async (req, res) => {
  if (req.params.provider !== pay.id) return res.sendStatus(404);
  let w = { valid: false };
  try { w = pay.webhook(req.body, req.headers); } catch { /* malformed */ }
  if (!w.valid) return res.sendStatus(401);
  res.sendStatus(200);
  if (w.session) confirm(w.session).catch((e) => console.error('[webhook]', e.message));
}));

app.use(express.json({ limit: '8mb' }));
app.use('/uploads', express.static(UPLOADS, { maxAge: '30d', immutable: true, fallthrough: false }));
app.use(express.static(path.join(ROOT, 'public'), { maxAge: 0 }));

// JSON-only writes: browsers can't send these cross-site without permission, which blocks forged requests.
app.use('/api', (req, res, next) => {
  if (req.method !== 'GET' && !req.is('application/json')) return res.status(415).json({ error: 'Unsupported request.' });
  res.set('Cache-Control', 'no-store');
  next();
});
app.use((req, res, next) => { req.user = sessions.user(req); next(); });
const needUser = (req, res, next) => (req.user ? next() : res.status(401).json({ error: 'Please sign in to continue.' }));
const needOwner = (req, res, next) => (req.user && req.user.role === 'admin' ? next() : res.status(req.user ? 403 : 401).json({ error: 'Only the shop owner can do that.' }));

/* ----- accounts ----- */
const authLimit = auth.limiter({ max: 20, windowMs: 15 * 60e3 });
const DUMMY = auth.hashPassword(crypto.randomBytes(9).toString('hex'));

app.get('/api/config', (req, res) => res.json(CFG));
app.get('/api/auth/me', (req, res) => res.json({ user: pubUser(req.user) }));

app.post('/api/auth/signup', h(async (req, res) => {
  if (!authLimit(req.ip)) fail('Too many attempts. Wait 15 minutes and try again.', 429);
  const b = req.body || {};
  const name = str(b.name, 100), email = str(b.email, 200).toLowerCase(), phone = str(b.phone, 40), pw = String(b.password || '');
  if (name.length < 2) fail('Enter your full name.');
  if (!validEmail(email)) fail('Enter a valid email address, like name@example.com.');
  if (phone.replace(/\D/g, '').length < 7) fail('Enter a phone number we can reach you on.');
  if (pw.length < 8 || pw.length > 200) fail('Your password needs at least 8 characters.');
  if (q.userByEmail.get(email)) fail('An account with this email already exists. Sign in instead.', 409);
  const id = newId('u_');
  q.insertUser.run(id, 'customer', name, email, phone, '', '', auth.hashPassword(pw), now());
  sessions.start(req, res, id);
  res.status(201).json({ user: pubUser(q.userById.get(id)) });
}));

app.post('/api/auth/login', h(async (req, res) => {
  if (!authLimit(req.ip)) fail('Too many attempts. Wait 15 minutes and try again.', 429);
  const email = str(req.body && req.body.email, 200).toLowerCase(), pw = String((req.body && req.body.password) || '');
  const u = q.userByEmail.get(email);
  const ok = auth.verifyPassword(pw, u ? u.pw : DUMMY) && !!u;
  if (!ok) fail("That email and password don't match. Check them and try again.", 401);
  sessions.start(req, res, u.id);
  res.json({ user: pubUser(u) });
}));

app.post('/api/auth/logout', (req, res) => { sessions.end(req, res); res.json({ ok: true }); });

app.patch('/api/account', needUser, (req, res) => {
  const b = req.body || {}, u = req.user;
  const next = {
    name: b.name != null ? str(b.name, 100) : u.name, phone: b.phone != null ? str(b.phone, 40) : u.phone,
    address: b.address != null ? str(b.address, 200) : u.address, city: b.city != null ? str(b.city, 100) : u.city,
    zoneId: u.zone_id || '',
  };
  if (b.zoneId != null) {
    const zid = str(b.zoneId, 80);
    if (zid && zid !== 'pickup' && !q.zoneById.get(zid)) fail('Choose a delivery location from the list.');
    next.zoneId = zid;
    const z = zid && zid !== 'pickup' ? q.zoneById.get(zid) : null;
    if (z) next.city = z.name;
  }
  if (next.name.length < 2) fail('Enter your full name.');
  q.updateUser.run(next.name, next.phone, next.address, next.city, next.zoneId, u.id);
  res.json({ user: pubUser(q.userById.get(u.id)) });
});

app.post('/api/account/password', needUser, (req, res) => {
  const b = req.body || {};
  if (!auth.verifyPassword(String(b.current || ''), req.user.pw)) fail('Your current password is not right.', 400);
  const pw = String(b.next || '');
  if (pw.length < 8 || pw.length > 200) fail('Your new password needs at least 8 characters.');
  q.setPw.run(auth.hashPassword(pw), req.user.id);
  sessions.endAllFor(req.user.id);
  sessions.start(req, res, req.user.id);
  res.json({ ok: true });
});

/* ----- shop ----- */
app.get('/api/products', needUser, (req, res) => res.json({ products: q.productsActive.all().map(product) }));
app.get('/api/delivery', needUser, (req, res) => res.json({ settings: deliverySettings(), zones: q.zonesActive.all().map(zoneView) }));

app.post('/api/orders', needUser, (req, res) => {
  const b = req.body || {};
  const items = Array.isArray(b.items) ? b.items.slice(0, 50) : [];
  if (!items.length) fail('Your bag is empty.');
  const d = b.delivery || {};
  const ds = deliverySettings();
  const zoneId = str(d.zoneId, 80);
  let zone = null;
  if (zoneId === 'pickup') {
    if (!ds.pickup) fail('Pickup at the shop is not available right now. Choose a delivery location.');
  } else {
    zone = zoneId ? q.zoneById.get(zoneId) : null;
    if (!zone || !zone.active) fail('Choose your delivery location from the list.');
  }
  const delivery = zone
    ? { method: 'delivery', zoneId: zone.id, name: str(d.name, 100), phone: str(d.phone, 40), address: str(d.address, 200), city: zone.name, region: zone.region, km: zone.km, notes: str(d.notes, 500) }
    : { method: 'pickup', zoneId: 'pickup', name: str(d.name, 100), phone: str(d.phone, 40), address: '', city: '', notes: str(d.notes, 500) };
  if (delivery.name.length < 2) fail('Enter the name of the person receiving the order.');
  if (delivery.phone.replace(/\D/g, '').length < 7) fail('Enter a phone number we can call about the order.');
  if (zone && delivery.address.length < 4) fail('Enter your house address or a landmark near you, so the rider can find you.');

  const order = db.tx(() => {
    const want = {};
    const lines = items.map((it) => {
      const p = q.productById.get(str(it.productId, 60));
      if (!p || !p.active) fail('One of the items in your bag is no longer available. Remove it and try again.', 409);
      const sizes = JSON.parse(p.sizes || '[]');
      const size = str(it.size, 30);
      if (sizes.length && !sizes.includes(size)) fail(`Choose a size for ${p.name}.`);
      const qty = Math.max(1, Math.min(20, parseInt(it.qty, 10) || 1));
      want[p.id] = (want[p.id] || 0) + qty;
      if (p.stock != null && p.stock < want[p.id]) fail(p.stock === 0 ? `${p.name} has just sold out. Remove it from your bag to continue.` : `Only ${p.stock} of ${p.name} left. Lower the quantity to continue.`, 409);
      return { productId: p.id, name: p.name, size: sizes.length ? size : '', qty, price: p.price, image: p.image, art: p.art ? JSON.parse(p.art) : null };
    });
    const subtotal = lines.reduce((s, i) => s + i.price * i.qty, 0);
    const fee = Delivery.feeFor(zone || 'pickup', ds, subtotal);
    let code;
    do { code = randCode(8); } while (q.orderByCode.get(code));
    const t = now();
    const r = q.insertOrder.run(code, req.user.id, JSON.stringify(lines), subtotal, fee, subtotal + fee, CFG.currency, JSON.stringify(delivery), pay.id, t, t);
    return q.orderById.get(r.lastInsertRowid);
  });
  const v = broadcast(order.id, 'created');
  res.status(201).json({ order: v });
});

app.get('/api/orders', needUser, (req, res) => res.json({ orders: q.ordersOfUser.all(req.user.id).map(orderView) }));
app.get('/api/orders/:code', needUser, (req, res) => res.json({ order: orderView(ownOrder(req)) }));
app.get('/api/orders/:code/events', needUser, (req, res) => { const o = ownOrder(req); live.watchOrder(req, res, o.code); });

app.post('/api/orders/:code/pay', needUser, h(async (req, res) => {
  const o = ownOrder(req);
  if (o.paid_at) fail('This order is already paid.', 409);
  if (o.status === 'cancelled') fail('This order was cancelled, so it can no longer be paid.', 409);
  const r = await pay.start({ order: orderView(o), email: req.user.email, baseUrl: baseUrl(req), shopName: CFG.shopName });
  if (r.session) q.setSession.run(r.session, pay.id, now(), o.id);
  res.json(r.redirectUrl ? { redirectUrl: r.redirectUrl } : { demo: true });
}));

app.post('/api/orders/:code/demo-pay', needUser, (req, res) => {
  if (pay.id !== 'demo') fail('Test payments are switched off on this shop.', 403);
  const o = ownOrder(req);
  if (o.status === 'cancelled') fail('This order was cancelled, so it can no longer be paid.', 409);
  if (req.body && req.body.outcome === 'success') {
    markPaid(o.id, { provider: 'demo', label: 'Test card (no real money)', ref: `TEST-${randCode(10)}` });
  } else {
    q.setPayError.run('The test card was declined. No money was taken.', now(), o.id);
  }
  res.json({ order: orderView(q.orderById.get(o.id)) });
});

app.post('/api/orders/:code/verify', needUser, h(async (req, res) => {
  const o = ownOrder(req);
  if (!o.paid_at && o.payment_session) await confirm(o.payment_session);
  res.json({ order: orderView(q.orderById.get(o.id)) });
}));

app.post('/api/orders/:code/cancel', needUser, (req, res) => {
  const o = ownOrder(req);
  if (o.paid_at || o.status !== 'pending_payment') fail('This order is already paid. Contact the shop to cancel it.', 409);
  const t = now();
  db.tx(() => { q.setStatus.run('cancelled', t, o.id); q.addEvent.run(o.id, 'cancelled', 'Cancelled by you before payment.', t); });
  res.json({ order: broadcast(o.id, 'updated') });
});

/* ----- payment returns ----- */
app.get('/payment/callback/paystack', h(async (req, res) => {
  const ref = str(req.query.reference || req.query.trxref, 120);
  let code = ref.split('-')[0];
  try { code = (await confirm(ref)) || code; } catch (e) { console.error('[paystack callback]', e.message); }
  const o = q.orderByCode.get(code);
  if (!o) return res.redirect('/#orders');
  res.redirect(o.paid_at ? `/?payment=success#receipt-${o.code}` : `/?payment=failed#pay-${o.code}`);
}));

app.get('/payment/callback/stripe', h(async (req, res) => {
  if (req.query.cancelled) return res.redirect(`/?payment=cancelled#pay-${encodeURIComponent(str(req.query.cancelled, 20))}`);
  let code = null;
  try { code = await confirm(str(req.query.session_id, 200)); } catch (e) { console.error('[stripe callback]', e.message); }
  const o = code && q.orderByCode.get(code);
  if (!o) return res.redirect('/#orders');
  res.redirect(o.paid_at ? `/?payment=success#receipt-${o.code}` : `/?payment=failed#pay-${o.code}`);
}));

/* ----- owner dashboard ----- */
app.get('/api/admin/summary', needOwner, (req, res) => {
  const start = new Date(); start.setHours(0, 0, 0, 0);
  res.json({
    toFulfil: q.countStatus.get().n,
    revenueToday: q.revenueSince.get(start.toISOString()).s,
    revenue30: q.revenueSince.get(new Date(Date.now() - 30 * 86400e3).toISOString()).s,
    customers: q.countCustomers.get().n,
  });
});
app.get('/api/admin/orders', needOwner, (req, res) => res.json({ orders: q.ordersAll.all().map(orderView) }));
app.get('/api/admin/events', needOwner, (req, res) => live.watchAll(req, res));

app.patch('/api/admin/orders/:code', needOwner, (req, res) => {
  const o = ownOrder(req), b = req.body || {};
  const status = str(b.status, 30), note = str(b.note, 500);
  if (!STATUSES.includes(status)) fail('Choose a status.');
  if (status === 'pending_payment' && o.paid_at) fail('This order is already paid, so it cannot go back to awaiting payment.');
  if (!['pending_payment', 'cancelled', 'paid'].includes(status) && !o.paid_at) fail('Mark the order as paid first. Orders are only prepared once payment is confirmed.');
  const t = now();
  q.setShipping.run(b.courier != null ? str(b.courier, 80) : o.courier, b.trackingNo != null ? str(b.trackingNo, 80) : o.tracking_no, t, o.id);
  if (status === 'paid' && !o.paid_at) {
    markPaid(o.id, { provider: 'manual', label: 'Paid in shop (cash or transfer)', ref: 'Recorded by shop' });
    if (note) { db.prepare('UPDATE order_events SET note = ? WHERE id = (SELECT MAX(id) FROM order_events WHERE order_id = ?)').run(note, o.id); broadcast(o.id, 'updated'); }
  } else if (status !== o.status || note) {
    db.tx(() => {
      if (status === 'cancelled' && o.status !== 'cancelled' && o.paid_at) JSON.parse(o.items).forEach((i) => q.returnStock.run(i.qty, i.productId));
      q.setStatus.run(status, t, o.id);
      q.addEvent.run(o.id, status, note, t);
    });
    broadcast(o.id, 'updated');
  } else {
    broadcast(o.id, 'updated');
  }
  res.json({ order: orderView(q.orderById.get(o.id)) });
});

function cleanProduct(b, existing) {
  const name = str(b.name, 120), category = str(b.category, 60) || 'Other';
  const price = Math.round(Number(b.price));
  if (name.length < 2) fail('Give the product a name.');
  if (!Number.isFinite(price) || price <= 0) fail('Enter a price above zero.');
  const sizes = (Array.isArray(b.sizes) ? b.sizes : []).map((s) => str(s, 30)).filter(Boolean).slice(0, 30);
  const stock = b.stock == null || b.stock === '' ? null : Math.max(0, parseInt(b.stock, 10) || 0);
  let image = b.image == null ? null : String(b.image);
  if (image && !/^(\/uploads\/[a-f0-9]{24}|products\/[a-z0-9-]+)\.(jpg|png|webp)$/.test(image)) image = existing ? existing.image : null;
  const a = b.art || (existing && existing.art ? JSON.parse(existing.art) : null) || {};
  const art = { kind: ART_KINDS.includes(a.kind) ? a.kind : 'shirt', color: HEX.test(a.color) ? a.color : '#C9CFCB', accent: HEX.test(a.accent) ? a.accent : undefined, bg: HEX.test(a.bg) ? a.bg : '#E6E9E5' };
  return { name, category, price, sizes, stock, description: str(b.description, 1000), image, art, active: b.active ? 1 : 0 };
}

app.get('/api/admin/products', needOwner, (req, res) => res.json({ products: q.productsAll.all().map(product) }));
app.post('/api/admin/products', needOwner, (req, res) => {
  const p = cleanProduct(req.body || {}), id = newId('p_');
  q.insertProduct.run(id, p.name, p.category, p.price, JSON.stringify(p.sizes), p.stock, p.description, p.image, JSON.stringify(p.art), p.active, now());
  res.status(201).json({ product: product(q.productById.get(id)) });
});
app.put('/api/admin/products/:id', needOwner, (req, res) => {
  const ex = q.productById.get(str(req.params.id, 60));
  if (!ex) fail('That product no longer exists.', 404);
  const p = cleanProduct(req.body || {}, ex);
  q.updateProduct.run(p.name, p.category, p.price, JSON.stringify(p.sizes), p.stock, p.description, p.image, JSON.stringify(p.art), p.active, ex.id);
  res.json({ product: product(q.productById.get(ex.id)) });
});
app.delete('/api/admin/products/:id', needOwner, (req, res) => { q.deleteProduct.run(str(req.params.id, 60)); res.json({ ok: true }); });

app.post('/api/admin/uploads', needOwner, (req, res) => {
  const m = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String((req.body && req.body.dataUrl) || ''));
  if (!m) fail("That file isn't a photo we can use. Choose a JPG, PNG or WebP image.");
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 5 * 1024 * 1024) fail('That photo is too large. Use one under 5 MB.');
  const sig = buf.subarray(0, 12).toString('hex');
  const okType = (m[1] === 'jpeg' && sig.startsWith('ffd8ff')) || (m[1] === 'png' && sig.startsWith('89504e47')) || (m[1] === 'webp' && sig.startsWith('52494646') && sig.slice(16, 24) === '57454250');
  if (!okType) fail("That file isn't a photo we can use. Choose a JPG, PNG or WebP image.");
  const name = `${crypto.randomBytes(12).toString('hex')}.${m[1] === 'jpeg' ? 'jpg' : m[1]}`;
  fs.writeFileSync(path.join(UPLOADS, name), buf);
  res.status(201).json({ url: `/uploads/${name}` });
});

app.get('/api/admin/delivery', needOwner, (req, res) => res.json({ settings: deliverySettings(), zones: q.zonesAll.all().map(zoneView) }));
app.put('/api/admin/delivery/settings', needOwner, (req, res) => {
  const st = Delivery.settings(req.body || {});
  if (st.maxFee && st.maxFee < st.minFee) fail('The highest fee must be more than the lowest fee.');
  q.putSetting.run('delivery', JSON.stringify(st));
  res.json({ settings: deliverySettings() });
});
function cleanZone(b) {
  const name = str(b.name, 80), region = str(b.region, 40), km = Number(b.km);
  if (name.length < 2) fail('Enter the town or area name.');
  if (!Number.isFinite(km) || km < 0 || km > 2000) fail('Enter the distance from the shop in km.');
  const fee = b.fee == null || b.fee === '' ? null : Math.round(Number(b.fee));
  if (fee != null && !(fee >= 0)) fail('Enter a fixed fee, or leave it empty.');
  return { name, region, km: Math.round(km * 10) / 10, fee, active: b.active === false ? 0 : 1 };
}
app.post('/api/admin/delivery/zones', needOwner, (req, res) => {
  const z = cleanZone(req.body || {});
  const id = `z-${z.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40)}-${crypto.randomBytes(2).toString('hex')}`;
  q.insertZone.run(id, z.name, z.region, z.km, z.fee, z.active);
  res.status(201).json({ zone: zoneView(q.zoneById.get(id)) });
});
app.put('/api/admin/delivery/zones/:id', needOwner, (req, res) => {
  const ex = q.zoneById.get(str(req.params.id, 80));
  if (!ex) fail('That location no longer exists.', 404);
  const z = cleanZone(req.body || {});
  q.updateZone.run(z.name, z.region, z.km, z.fee, z.active, ex.id);
  res.json({ zone: zoneView(q.zoneById.get(ex.id)) });
});
app.delete('/api/admin/delivery/zones/:id', needOwner, (req, res) => { q.deleteZone.run(str(req.params.id, 80)); res.json({ ok: true }); });

app.get('/api/admin/customers', needOwner, (req, res) => res.json({
  customers: q.customers.all().map((c) => ({ id: c.id, name: c.name, email: c.email, phone: c.phone, city: c.city, createdAt: c.created_at, orders: c.orders, spent: c.spent })),
}));
app.post('/api/admin/customers/:id/reset-password', needOwner, (req, res) => {
  const u = q.userById.get(str(req.params.id, 60));
  if (!u || u.role !== 'customer') fail('Customer not found.', 404);
  const temp = `${randCode(4)}-${randCode(4)}`;
  q.setPw.run(auth.hashPassword(temp), u.id);
  sessions.endAllFor(u.id);
  res.json({ tempPassword: temp });
});

/* ----- fallbacks ----- */
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));
app.use((req, res) => res.redirect('/'));
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'That upload is too large. Use a photo under 5 MB.' });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'The request could not be read. Please try again.' });
  const status = err.status || 500;
  if (status >= 500 && !(err instanceof HttpError) && status !== 502) console.error(err);
  res.status(status).json({ error: err instanceof HttpError || status === 502 || status === 429 ? err.message : 'Something went wrong on our side. Please try again.' });
});

const PORT = Number(env.PORT) || 3000;
app.listen(PORT, () => {
  console.log(`\n${CFG.shopName} is running on http://localhost:${PORT}`);
  console.log(`Payments: ${pay.id === 'demo' ? 'TEST MODE (no real money)' : pay.name}. Currency: ${CFG.currency}.`);
  if (seeded) console.log(`Added ${seeded} products from seed/products.json. Edit them under Owner dashboard > Products.`);
  if (seededZones) console.log(`Added ${seededZones} delivery locations. Adjust prices and distances under Owner dashboard > Delivery.`);
});
